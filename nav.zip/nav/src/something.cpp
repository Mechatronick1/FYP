#include "ros/ros.h"
#include <stdio.h>
#include "std_msgs/Float32.h"
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <Eigen/Core>
#include "rosgraph_msgs/Clock.h"
#include <time.h>
//#include "stateEstimator.h"
//#include "skew.h"


#define SYS_ID_NUM_TIMESTEPS 100


int main(int argc, char **argv) {

 ros::NodeHandle nh;

 Eigen::MatrixXd rCBb(3,1);
            rCBb <<
                1,
                2,
                3;
	
	return 0;
}

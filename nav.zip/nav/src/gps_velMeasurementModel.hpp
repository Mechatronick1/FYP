#include <iostream>
#include "stateEstimator.h"
void gps_velMeasurementModel(const Eigen::VectorXd & x, const boatParameters params, Eigen::VectorXd & vel_out, Eigen::MatrixXd & SR);

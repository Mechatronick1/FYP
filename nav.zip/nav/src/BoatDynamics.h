#include "ros/ros.h"
#include <stdio.h>
#include "std_msgs/Float32.h"
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <eigen3/Eigen/Dense>
#include "rosgraph_msgs/Clock.h"
#include <time.h>
#include "skew.h"
#include "robotParameters.h"
#include "eulerKinematicTransformation.h"
#include "gaussian.hpp"
#include "AccMeasurementModel.hpp"

void BoatDynamics::operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx);

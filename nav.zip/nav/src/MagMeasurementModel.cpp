#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include <eigen3/Eigen/Dense>
//#include "stateEstimator.h"
#include "MagMeasurementModel.hpp"


void MagMeasurementModel(const Eigen::VectorXd & x, const boatParameters params, Eigen::VectorXd & mag_out, Eigen::MatrixXd & SR){

double sigmar = 0.014; //Apparently stdev of magnetometer (rad)
std::cout << "------------------STARTING MAGNETOMETER MEASUREMENT MODEL-------------------" << std::endl;
        //This calculation should be performed but just hard coding matrix values since i was getting errors 
        /* Eigen::MatrixXd eye3(3,3);
            eye3 <<
                1,0,0,
                0,1,0,
                0,0,1;

        double calc = (sigmar*sigmar)*eye3;
        */

        Eigen::MatrixXd calc(3,3);
            calc <<
                0.0002,0,0,
                0,0.0002,0,
                0,0,0.0002;
        //Finding the cholesky decomposition
        SR = calc.llt().matrixL();

        std::cout << "SR: " << SR << std::endl;

        Eigen::VectorXd rMCb(3);
            rMCb <<
                0,
                0,
                0;
        // Check GyroMeasurementModel for comments about needing to double check to ensure this matrix is correct
        Eigen::MatrixXd Rbm(3,3);
            Rbm <<
                1,0,0,
                0,1,0,
                0,0,1;
        
        
        //eta
        Eigen::VectorXd eta(6,1);
        eta << x(0),
               x(1),
               x(2),
               x(3),
               x(4),
               x(5); 
        std::cout << "Changing first 6 values of x into eta: " << eta << std::endl;
        
        //nu
        Eigen::VectorXd nu(6,1);
        nu <<  x(6),
               x(7),
               x(8),
               x(9),
               x(10),
               x(11);

        std::cout << "Changing last 6 values of x into nu: " << nu << std::endl;
        
        // Magnetic field vector????????????????? (copying matlab for now)
        Eigen::VectorXd mn(3);
            mn <<
                1,
                1,
                1;

        Eigen::MatrixXd Rnb(3,3);
        Rnb = R(eta);

        std::cout << "Rnb " << Rnb << std::endl;


        Eigen::VectorXd rBNn(3);
        rBNn << eta(3),
                eta(4),
                eta(5);

        std::cout << "rBNn: " << rBNn << std::endl;
        double roll = eta(3);
        double pitch = eta(4);
        double yaw = eta(5);

        //Eigen::VectorXd mag_out(3);
        mag_out.resize(3);
        mag_out(0) = roll;
        mag_out(1) = pitch;
        mag_out(2) = yaw;
        std::cout << "mag_out: " << mag_out << std::endl;

}
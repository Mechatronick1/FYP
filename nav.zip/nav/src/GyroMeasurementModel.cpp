#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include <eigen3/Eigen/Dense>
//#include <Eigen/Geometry>
#include "stateEstimator.h"
#include "GyroMeasurementModel.hpp"
//#include <tf/tf.h>
//#include "stateEstimator.h"

void GyroMeasurementModel(const Eigen::VectorXd & x, const boatParameters params,Eigen::VectorXd & gyro_out, Eigen::MatrixXd & SR){
//std::cout << "--------------------STARTING GYRO MEASUREMENT MODEL----------------------" << std::endl;
double sigmar = 0.0014; //Apparently stdev of accelerometer (ms^-2)

        //This calculation should be performed but just hard coding matrix values since i was getting errors 
        /* Eigen::MatrixXd eye3(3,3);
            eye3 <<
                1,0,0,
                0,1,0,
                0,0,1;

        double calc = (sigmar*sigmar)*eye3;
        */
        // std::cout << "Roll dragged into function \n" << params.roll << std::endl;
        // std::cout << "Pitch dragged into function \n" << params.pitch << std::endl;
        // std::cout << "Yaw dragged into function \n" << params.yaw << std::endl;

// -------------Converting quaternion to euler (roll pitch yaw)----------
//        tf::Quaternion q(
//         gyrox,
//         gyroy,
//         gyroz,
//         gyrow);

//         q.normalize();

//         tf::Matrix3x3 m(q);
//         double roll, pitch, yaw;
//         m.getRPY(roll, pitch, yaw);

//         std::cout << "Roll: "<< roll << std::endl;
//         std::cout << "Pitch: "<< pitch << std::endl;
//         std::cout << "Yaw: "<< yaw << std::endl;
//-----------------------------------------------------------------------

       // Matrix below is just sigmar^2*eye(3)
        Eigen::MatrixXd calc(3,3);
            calc <<
                0.00000196,0,0,
                0,0.00000196,0,
                0,0,0.00000196;
        //Finding the cholesky decomposition
        SR = calc.llt().matrixL();

      //  std::cout << "SR: " << SR << std::endl;

        // Sensor position with reference to B in b-coordinates
        Eigen::MatrixXd rMCb(3,1);
            rMCb <<
                0,
                0,
                0;
        // Fixed rotation matrix for sensor coordinate system (MAY NEED TO CHANGE)
        Eigen::MatrixXd Rbm(3,3);
            Rbm <<
                1,0,0,
                0,1,0,
                0,0,1;
        
        //eta
        // Eigen::VectorXd eta(6,1);
        // eta << x(0),
        //        x(1),
        //        x(2),
        //        x(3),
        //        x(4),
        //        x(5)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//-----------------------------------------CHANGE LATITUDE LONGITUDE AND ALTITUDE HERE FOR N E D

//MAY NEED TO CHANGE THESE VALUES BACK TO X(0), X(1), X(2) ETC...
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
         Eigen::VectorXd eta(6,1);
        eta << x(0),
               x(1),
               x(2),
               x(3),
               x(4),
               x(5);

        //std::cout << "Changing first 6 values of x into eta: " << eta << std::endl;
        
        //nu
        // Eigen::VectorXd nu(6,1);
        // nu <<  x(6),
        //        x(7),
        //        x(8),
        //        x(9),
        //        x(10),
        //        x(11);

        Eigen::VectorXd nu(6,1);
        nu <<  x(6),
               x(7),
               x(8),
               x(9),
               x(10),
               x(11);


        //std::cout << "Changing last 6 values of x into nu: " << nu << std::endl;
        Eigen::VectorXd dx(12);


        //Running boatDynamics 
        BoatDynamics model;
        model(x,dx);

        Eigen::VectorXd xdot(12,1);
        xdot <<  dx(0),
                 dx(1),
                 dx(2),
                 dx(3),
                 dx(4),
                 dx(5),
                 dx(6),
                 dx(7),
                 dx(8),
                 dx(9),
                 dx(10),
                 dx(11);
        //std::cout << "xdot: " << xdot << std::endl;


        Eigen::VectorXd wBNb(3,1);
        wBNb << xdot(3), //dphi
                xdot(4), //dtheta
                xdot(5); //dpsi
      //  std::cout << "wBNb: " << wBNb << std::endl;

        Eigen::MatrixXd eye3(3,3);
        eye3 <<
                1,0,0,
                0,1,0,
                0,0,1;

///////Adding noise in simulateMeasurement_gyro.cpp
        // Eigen::VectorXd y(3);
        // y << eye3*Rbm*wBNb;
        // std::cout << "y: " << y << std::endl;

        double first_gyro = (wBNb(0) - 9.81*sin(eta(3))*sin(eta(5))-9.81*cos(eta(3))*cos(eta(5))*sin(eta(4)));
        //std::cout << "first: " << first << std::endl;

        double second_gyro = (wBNb(1) + 9.81*cos(eta(5))*sin(eta(3))-9.81*cos(eta(3))*sin(eta(5))*sin(eta(4)));

        double third_gyro = (wBNb(2) - 9.81*cos(eta(3))*cos(eta(4)));

        // double first_gyro = wBNb(0);
        // //std::cout << "first: " << first << std::endl;

        // double second_gyro = wBNb(1);

        // double third_gyro = wBNb(2);

        gyro_out.resize(3);
        gyro_out(0) = first_gyro;
        gyro_out(1) = second_gyro;
        gyro_out(2) = third_gyro;
}
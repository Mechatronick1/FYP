#include <iostream>
#include "stateEstimator.h"
Eigen::VectorXd simulateMeasurement_mag(Eigen::VectorXd & x, Eigen::VectorXd & dx, boatParameters params);

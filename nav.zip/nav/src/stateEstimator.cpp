#include "ros/ros.h"
#include <stdio.h>
#include "std_msgs/Float32.h"
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <Eigen/Core>
// #include "rosgraph_msgs/Clock.h"
// #include <time.h>
#include "skew.h"
#include "eulerKinematicTransformation.h"
#include "gaussian.hpp"
// #include <sensor_msgs/NavSatFix.h>
#include "AccMeasurementModel.hpp"
#include "GyroMeasurementModel.hpp"
#include "MagMeasurementModel.hpp"
#include "gps_posMeasurementModel.hpp"
#include "gps_velMeasurementModel.hpp"
#include "simulateMeasurement_gps_pos.hpp"
#include "simulateMeasurement_gps_vel.hpp"
#include "simulateMeasurement_acc.hpp"
#include "simulateMeasurement_gyro.hpp"
#include "simulateMeasurement_mag.hpp"
#include "measurementModels.hpp"
#include "stateEstimator.h"

#define SYS_ID_NUM_TIMESTEPS 100


// class mainClass{
// private:
        
//         ros::NodeHandle nh;
//         ros::Subscriber subClock, subGPS_position;

//         rosgraph_msgs::Clock simTime;
        
//         std::stringstream ss;
//         int i;
// public:
//         sensor_msgs::NavSatFix positionVal[3];
// mainClass() { // constructor starts the subscriber and publishers
//         subClock  = nh.subscribe("/clock", 1, &mainClass::clockReadCallback, this);
//         subGPS_position = nh.subscribe("/wamv/sensors/gps/gps/fix", 10, &mainClass::positionReadCallback, this);
//         }

//         void clockReadCallback(const rosgraph_msgs::Clock::ConstPtr& msg) {
//         // read simulation time and store it in variable
//         simTime.clock = msg->clock;

//         std::cout << simTime.clock << endl; 
//         }

// void positionReadCallback(const sensor_msgs::NavSatFix::ConstPtr& msg) {
//         positionVal[ 0].latitude = msg->latitude;
//         positionVal[ 1].longitude = msg->longitude;
//         positionVal[ 2].altitude = msg->altitude;
// }
        
// };



void BoatDynamics::operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx)
{
    boatParameters params;

        std::cout << "------------------start BoatDynamics-------------------" << endl;
        

    //    std::cout << "X LAD: \n" << x << endl;

    //std::cout << "Printing from param struct:  " << params.Iyy << endl;
    //std::cout << "Printing from param struct (mass):  " << params.m << endl;

   // double gn[3] = {0, 0, g}; //NOT SURE IF THIS CORRECT YET
    Eigen::MatrixXd gn(3,1);
            gn <<
                0,
                0,
                params.g;

    //std::cout << gn << std::endl; //PRINTING - Can comment this out when ready

    
    //Just 'I' when using our actual dynamics, but for matlab we will use IBb
    Eigen::MatrixXd IBb(3,3);
            IBb <<
                params.Ixx, params.Ixy, params.Ixz,
                params.Ixy, params.Iyy, params.Iyz,
                params.Ixz, params.Iyz, params.Izz;

    //std::cout << IBb << std::endl; //PRINTING - Can comment this out when ready

    //----------------------Sensor model params---------------------------
    //double b_acc = 0.002*9.81; 

    Eigen::MatrixXd rLCb(3,1);
            rLCb <<
                params.l_xL,
                params.l_yL,
                0;
   
    Eigen::MatrixXd rRCb(3,1);
            rRCb <<
                params.l_xR,
                params.l_yR,
                0;

    Eigen::MatrixXd rCBb(3,1);
            rCBb <<
                params.xG,
                params.yG,
                params.zG;

    Eigen::MatrixXd SrCBb(3, 3);
            SrCBb = skew(rCBb); //Correct matrix but gives -0 instead of 0, not sure if that will be a problem

    Eigen::MatrixXd zero3 = Eigen::MatrixXd::Zero(3,3);
    Eigen::MatrixXd zero31 = Eigen::MatrixXd::Zero(3,1);             
    Eigen::MatrixXd zero61 = Eigen::VectorXd::Zero(6);

//std::cout << "before eta, nu ting" << x << endl;

    Eigen::VectorXd    eta(6), nu(6);
        eta = x.head(6);
        nu = x.tail(6);

//std::cout << "after eta, nu ting" << endl;

 //       std::cout << "eta: " << eta << endl;
 //       std::cout << "nu: " << nu << endl;


    Eigen::Vector3d T;
         T <<   params.ThrCmdL,
                params.ThrCmdR,
                params.ThrCmdF;

    
    //double ThrAngF = 0.0; DONT NEED THIS ONE FOR MATLAB MODEL


// Hydrodynamic Drag and NL Drag Matrix
        Eigen::MatrixXd D = Eigen::MatrixXd::Zero(6, 6);
            D(0, 0) = params.X_u + params.X_uu * std::abs(nu[0]);
            D(1, 1) = params.Y_v + params.Y_vv * std::abs(nu[1]);
            D(2, 2) = params.Z_w + params.Z_ww * std::abs(nu[2]);
            D(3, 3) = params.K_p + params.K_pp * std::abs(nu[3]);
            D(4, 4) = params.M_q + params.M_qq * std::abs(nu[4]);
            D(5, 5) = params.N_r + params.N_rr * std::abs(nu[5]);


        Eigen::MatrixXd MRB(6, 6);
            MRB.topLeftCorner(3, 3) = params.m * Eigen::Matrix3d::Identity(3, 3);
            MRB.topRightCorner(3, 3) = -params.m * skew(rCBb);
            MRB.bottomLeftCorner(3, 3) = params.m * skew(rCBb);
            MRB.bottomRightCorner(3, 3) = IBb;

            //std::cout << MRB << std::endl;

// Hydrodynamic Mass Matrix
        Eigen::MatrixXd Ma = Eigen::MatrixXd::Zero(6, 6);
        Ma <<
                params.X_udot, 0, 0, 0, 0, 0,
                0, params.Y_vdot, 0, 0, 0, params.Y_rdot,
                0, 0, params.Z_wdot, 0, 0, 0,
                0, 0, 0, params.K_pdot, 0, 0,
                0, 0, 0, 0, params.M_qdot, 0,
                0, params.N_vdot, 0, 0, 0, params.N_rdot;


            //std::cout << MAM << std::endl;

    Eigen::MatrixXd M(6, 6);

            M = MRB - Ma;


    //std::cout << MassMatrix << std::endl;

   


    //----------------------------may need to input simulation parameters----------------

    //----------------------------Set initial conditions------------------------

    

    //Not sure if i need lines 25 --> 45 yet in runLab2.m

    //-----------------------Running the simulation------------------    

            // Function declared in header
            // file to find the sum
            //std::cout << "Sum is: "
            // << robotParameters(B, zG)
            //<< endl;

        //Copy sysidEcho if we want this in a seperate function

    //----------------------------------------------------BOAT DYNAMICS.m----------------------------------------------------------------------------

    //These values need to be changed to N E D phi theta psi
    //should be given by the sensor data i think
    
/* PROBABLY NEED TO CHANGE TO BE: dx.head(6) = eta (JUST LIKE WHAT IS DONE IN RK4 CALCULATION) - DONT THINK SO ACTUALLY

        Eigen::VectorXd eta(6,1);
        eta << x;
        std::cout << "Changing x into eta: " << eta << endl;
*/


//     Eigen::MatrixXd eta(6, 1);
//             eta <<
//                 0,
//                 0,
//                 0,
//                 0,
//                 0,
//                 0;

//     //These values need to be changed to u, v, w, p, q, r
//     //should be given by the sensor data i think
//     Eigen::VectorXd nu(6);
//             nu << 
//             0,
//             0,
//             0,
//             0,
//             0,
//             0;

        //double mean = (nu(0) + nu(1) + nu(2) + nu(3) + nu(4) + nu(5))/6;
        //std::cout << "Mean:" << mean << endl;

        // This accesses element 1 of nu vector:    
        // std::cout << "Nu element 1:" << nu(1) << endl;
          


        //Dont think this is correct either
    Eigen::Vector3d wBNb = Eigen::Vector3d::Zero(3);
            wBNb << nu[3], nu[4], nu[5];            


    Eigen::MatrixXd JK = Eigen::MatrixXd::Zero(6, 6);
            JK << J(eta);    //Think this is close enough in values to matlab 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*

                                NEED TO EDIT THIS ACTUATOR CONFIGURATION TO TAKE IN THE INPUTS FROM CONTROL SYSTEM

*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Actuator configuration (e_LR)
//     Eigen::MatrixXd actuatorConfig(3, 2);
//             actuatorConfig <<
//                 cos(ThrAngL), cos(ThrAngR),
//                 sin(ThrAngL), sin(ThrAngR),
//                 -l_yL * cos(ThrAngL) - l_xL * sin(ThrAngL), -l_yR * cos(ThrAngR) - l_xR * sin(ThrAngR);
        



        ////////MAY NEED TO DOUBLE CHECK THE POSITION OF MOTORS RELATIVE TO THEIR 
Eigen::MatrixXd B = Eigen::MatrixXd::Zero(6, 3);
        B <<
        cos(params.ThrAngL), cos(params.ThrAngR), cos(params.ThrAngF),
        sin(params.ThrAngL), sin(params.ThrAngR), sin(params.ThrAngF),
        0,0,0,
        0,0,0,
        0,0,0,
        -params.l_yL * cos(params.ThrAngL) - params.l_xL * sin(params.ThrAngL), -params.l_yR * cos(params.ThrAngR) - params.l_xR * sin(params.ThrAngR), params.l_xF * sin(params.ThrAngF);

 
//---------------THIS ISNT GIVING THE SAME VALUES AS MATLAB BUT MIGHT BE CORRECT WHEN USING THE PROPER VALUES---------------------------
 // Rigid Body Coriolis Matrix
            Eigen::MatrixXd CRB(6, 6);
            CRB.topLeftCorner(3, 3) = params.m * skew(wBNb);
            CRB.topRightCorner(3, 3) = -params.m * skew(wBNb) * skew(rCBb);
            CRB.bottomLeftCorner(3, 3) = params.m * skew(wBNb) * skew(rCBb);
            CRB.bottomRightCorner(3, 3) = -skew(wBNb);
            
    //    std::cout << "CRB : \n" << CRB << std::endl;


        // Eigen::MatrixXd Cam(6, 6);
        //         Cam << 
        //         0, 0, 0, 0, 0, (Y_vdot*nu(1) + Y_rdot*nu(5)),
        //         0, 0, 0, 0, 0, X_udot*nu(0),
        //         0, 0, 0, 0, 0, 0,
        //         0, 0, 0, 0, 0, 0,
        //         0, 0, 0, 0, 0, 0,
        //         0, 0, 0, (Y_vdot*nu(1) + Y_rdot*nu(5)), X_udot*nu(0), 0;

        // Hydrodynamic Coriolis Matrix
            Eigen::MatrixXd CA = Eigen::MatrixXd::Zero(6, 6);
            CA(0, 5) = params.Y_vdot * nu[1] + params.Y_rdot * nu[5];
            CA(1, 5) = params.X_udot * nu[0];
            CA(5, 0) = params.Y_vdot * nu[1] + params.Y_rdot * nu[5];
            CA(5, 1) = params.X_udot * nu[0];

        Eigen::MatrixXd C = Eigen::MatrixXd::Zero(6, 6);
            C = CRB-CA;  

    //    std::cout << "C final \n" << C << endl;

//         Eigen::MatrixXd g_eta(6, 1);
//             g_eta << 
//                 0,
//                 0,
//                 param.g*eta[2],
//                 param.g*eta[3],
//                 param.g*eta[4],
//                 0;
//  std::cout << "g_eta \n" << g_eta << endl;

        Eigen::MatrixXd G = Eigen::MatrixXd::Zero(6, 1);
            G << JK * params.g * eta;

        Eigen::MatrixXd M_inv = Eigen::MatrixXd::Zero(6, 6);
            M_inv = M.inverse();

        Eigen::MatrixXd f1 = Eigen::MatrixXd::Zero(6, 1);
            f1 = JK * nu;

        Eigen::MatrixXd f2 = Eigen::MatrixXd::Zero(6, 1);
            f2 = -M_inv * ((C - D) * nu - G);

        Eigen::MatrixXd f = Eigen::MatrixXd::Zero(12, 1);
            f << f1,
                 f2;

        Eigen::MatrixXd h1 = Eigen::MatrixXd::Zero(6, 3);
            Eigen::MatrixXd h2 = Eigen::MatrixXd::Zero(6, 3);
            h2 = M_inv * B;
        
        //input
        Eigen::MatrixXd motor_input = Eigen::MatrixXd::Zero(12, 3);
            motor_input << h1,
                           h2;

        // add disturbances
        dx = Eigen::MatrixXd::Zero(12, 1);
            dx = f + (motor_input * T); // h = input


    //std::cout << "DX LAD \n" << dx << endl;

        // Eigen::VectorXd temp = -M.colPivHouseholderQr().solve((C-D)*nu-(JK*g_eta));
        // Eigen::VectorXd temp1 = M.colPivHouseholderQr().solve(Ba);

        // std::cout << "temp \n" << temp << endl;
        // std::cout << "temp1 \n" << temp1 << endl;


        // Eigen::VectorXd tempMat(12,1);
        //     tempMat << 
        //         JK*nu,
        //         temp;
        //         std::cout << "tempMat \n" << tempMat << endl;
        // Eigen::VectorXd tempMat1(12,1);
        //     tempMat1 << 
        //         zero61,
        //         temp1;
        //         std::cout << "tempMat1 \n" << tempMat1 << endl;

//std::cout << "temp = " << tempMat << endl;
        //WILL NEED TO CHECK IF THIS DX IS CORRECT    
          
        //Also think this is called muy, but will need to double check
//         dx = tempMat + tempMat1;
                
// std::cout << "Estimated states = \n " << dx << endl;





//measUpdate_UKF(mu0, m);
       
}


void BoatDynamics::operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, Eigen::MatrixXd & SQ){

        operator()(x,dx);
        SQ.resize(12,12);
        SQ.setZero();
        Eigen::MatrixXd SQ_t;
        SQ_t = Eigen::MatrixXd::Zero(6, 6);
        
        SQ_t.diagonal() << 0.02, 0.02, 0.01, 0.05, 0.05, 0.05; //0.2, 0.2, 0.01, 0.05, 0.05, 0.05
        SQ.topLeftCorner(6,6) = SQ_t;
        //std::cout << "SQ = " << SQ << endl;

}

void BoatDynamics::operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, Eigen::MatrixXd & SQ, Eigen::MatrixXd & Jx){

        operator()(x,dx,SQ);

       
        Jx.diagonal() << 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;
        

}



//      timeUpdateContinuous(mu,S,pm,timestep,mup,Sp);



//Change tempMat and tempMat1 to VectorXd


void stateEstimator() 
    {
       mainClass mainObj;
       
//mainObj for clock time

        std::cout << "++++++++++++++++++++++++++++JUST STARTED THE MAIN++++++++++++++++++++++++++++++++ " << endl;

        ros::Rate loop_rate(20); // Hz
        
        BoatDynamics pm;
        
       // measurementModels gps_pos;
       // measurementModels gps_vel;

        Eigen::VectorXd x(12);
            x <<
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0;
                
//Should be 13 for the accelerometer bias
    Eigen::VectorXd mu0(12);
            mu0 <<
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0;
                

    Eigen::MatrixXd S(12, 12);
            S <<
                0.003, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0.003, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0.003, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0.003, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0.003, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0.003, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0.001, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0.001, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0.001, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0.001, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.001, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.001;


        double timestep = 0.1;


        Eigen::VectorXd f1; 
        Eigen::VectorXd xp = Eigen::VectorXd::Zero(12);
        Eigen::VectorXd dx = Eigen::VectorXd::Zero(12);
        Eigen::VectorXd muy = Eigen::VectorXd::Zero(12);
        
        //Eigen::MatrixXd Sp(12,12), Syy(12,12);
        Eigen::MatrixXd Sp = Eigen::MatrixXd::Zero(12, 12);
        Eigen::MatrixXd Syy = Eigen::MatrixXd::Zero(12, 12);

        int count = 0;
        loop_rate.sleep();
        int counter = 0;
        

        boatParameters params;



    std::ofstream EAST, NORTH, UP, ROLL, PITCH, YAW, SURGE, SWAY, HEAVE, ROLL_RATE, PITCH_RATE, YAW_RATE;
    EAST.open("EAST.txt");
    NORTH.open("NORTH.txt");
    UP.open("UP.txt");
    ROLL.open("ROLL.txt");
    PITCH.open("PITCH.txt");
    YAW.open("YAW.txt");
    SURGE.open("SURGE.txt");
    SWAY.open("SWAY.txt");
    HEAVE.open("HEAVE.txt");
    ROLL_RATE.open("ROLL_RATE.txt");
    PITCH_RATE.open("PITCH_RATE.txt");
    YAW_RATE.open("YAW_RATE.txt");

        while (ros::ok()) {

        ros::spinOnce();
        std::cout << "---------------------------------START OF WHILE LOOP " << endl;
        
        // std::cout << "Latitude from sensor \n" << mainObj.positionVal[ 0].latitude << endl;
        // std::cout << "Longitude from sensor \n" << mainObj.positionVal[ 1].longitude << endl;
        // std::cout << "Altitude from sensor \n" << mainObj.positionVal[ 2].altitude << endl;
    
    
        if(counter == 0){
        params.origin_lat = mainObj.positionVal[ 0].latitude;
        params.origin_long = mainObj.positionVal[ 1].longitude;
        params.origin_alt = mainObj.positionVal[ 2].altitude;
        counter ++;
        }
//-----------------Latitude, longitude, and altitude position and velocity----------    GPS
        params.latitude = mainObj.positionVal[ 0].latitude;
        params.longitude = mainObj.positionVal[ 1].longitude;
        params.altitude = mainObj.positionVal[ 2].altitude;


        params.velx = mainObj.linearVelocity[ 0].vector.x;
        params.vely = mainObj.linearVelocity[ 1].vector.y;
        params.velz = mainObj.linearVelocity[ 2].vector.z;
//-------------Converting quaternion to euler (roll pitch yaw)-----------------------    MAGNETOMETER
        tf::Quaternion q(
        mainObj.IMU[ 0].orientation.x,
        mainObj.IMU[ 1].orientation.y,
        mainObj.IMU[ 2].orientation.z,
        mainObj.IMU[ 3].orientation.w);

        q.normalize();     

        tf::Matrix3x3 m(q);


        m.getRPY(params.roll,params.pitch,params.yaw);

        
        // std::cout << "Roll: "<< params.roll << std::endl;
        // std::cout << "Pitch: "<< params.pitch << std::endl;
        // std::cout << "Yaw: "<< params.yaw << std::endl;

//--------------------Roll rate, Pitch rate, Yaw rate-----------------------------    GYROMETER
        params.gyrox = mainObj.IMU[ 4].angular_velocity.x;
        params.gyroy = mainObj.IMU[ 5].angular_velocity.y;
        params.gyroz = mainObj.IMU[ 6].angular_velocity.z;

// //----------------------Angular acceleration--------------------------------------    ACCELEROMETER
        params.accx = mainObj.IMU[ 7].linear_acceleration.x;
        params.accy = mainObj.IMU[ 8].linear_acceleration.y;
        params.accz = mainObj.IMU[ 9].linear_acceleration.z;
    
    const Eigen::VectorXd y = simulateMeasurement_gps_pos(x, dx, params);
  //  std::cout << "Value returning from simulate measurement to main successfully position" << y << std::endl;
    const Eigen::VectorXd y1 = simulateMeasurement_gps_vel(x, dx, params);
 //   std::cout << "Value returning from simulate measurement to main successfully velocity" << y1 << std::endl;
    const Eigen::VectorXd y2 = simulateMeasurement_mag(x, dx, params);
  //  std::cout << "Value returning from simulate measurement to main successfully magnetometer" << y2 << std::endl;
    const Eigen::VectorXd y3 = simulateMeasurement_gyro(x, dx, params);
   // std::cout << "Value returning from simulate measurement to main successfully gyro" << y3 << std::endl;
    const Eigen::VectorXd y4 = simulateMeasurement_acc(x, dx, params);
  //  std::cout << "Value returning from simulate measurement to main successfully accelerometer" << y4 << std::endl;


    std::cout << "X filled with sensor measurements: " << x << std::endl;



assert(!x.hasNaN());

//   Eigen::VectorXd y(3);
//         y << 0.578319138288,
//             -0.179549029469,
//             1.13239693642;
    
    //    Eigen::VectorXd y(3);
    //                         y << 0.578319138288,
    //                             -0.179549029469,
    //                              1.13239693642;
       
        // simulateMeasurement_gps_vel(xp, dx, latitude,longitude,altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);
        // simulateMeasurement_Acc(xp, dx, latitude,longitude,altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);
        // simulateMeasurement_gyro(xp, dx, latitude, longitude, altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);

   //     std::cout << "Value returning from simulate measurement to main successfully" << y << std::endl;

    ////////-------------DONT THINK I SHOULD BE USING THESE AS THEY NEED TO BE CALLED INSIDE EACH SIMULATEMEASUREMENT FUNCTION---------------

        // gps_posMeasurementModel(xp, dx, origin_lat, origin_long, origin_alt,latitude,longitude,altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);
        // gps_velMeasurementModel(xp, dx, latitude,longitude,altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);
        // AccMeasurementModel(xp, dx, latitude,longitude,altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);
        // GyroMeasurementModel(xp, dx, latitude, longitude, altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);
        

        // Eigen::VectorXd ENU(3);
        // Eigen::MatrixXd SR(3,3);
 
//std::cout << "muy before timeupdatecontinuous" << muy << std::endl;
        
   //     std::cout << "----------------------------------------------x before timeupdate" << x << std::endl;
   //     std::cout << "----------------------------------------------S before timeupdate" << S << std::endl;
        
        timeUpdateContinuous(x,S,pm,params,timestep,xp,Sp);

    // std::cout << "Sp before measure" << Sp << std::endl;

   
        //MAYBE THIS X HAS TO BE XP OR SOMETHING??
       measurementUpdateUKF(xp,Sp,y,gps_posMeasurementModel,params,muy,Syy);
       measurementUpdateUKF(xp,Sp,y1,gps_velMeasurementModel,params,muy,Syy);
       measurementUpdateUKF(xp,Sp,y2,MagMeasurementModel,params,muy,Syy);
       measurementUpdateUKF(xp,Sp,y3,AccMeasurementModel,params,muy,Syy);
       measurementUpdateUKF(xp,Sp,y4,GyroMeasurementModel,params,muy,Syy);
        // measurementUpdateUKF(xp,Sp,y4,&GyroMeasurementModel,muy,Syy);


        EAST << muy(0) << endl;
        NORTH << muy(1) << endl;
        UP << muy(2) << endl;
        ROLL << muy(3) << endl;
        PITCH << muy(4) << endl;
        YAW << muy(5) << endl;
        SURGE << muy(6) << endl;
        SWAY << muy(7) << endl;
        HEAVE << muy(8) << endl;
        ROLL_RATE << muy(9) << endl;
        PITCH_RATE << muy(10) << endl;
        YAW_RATE << muy(11) << endl;

        // realEAST << xEast << endl;
        // realNORTH << yNorth << endl;
        // realUP << zUp << endl;
        // realROLL << params.real_roll << endl;
        // realPITCH << params.real_pitch << endl;
        // realYAW << params.real_yaw << endl;
        // realSURGE << params.real_SURGE << endl;
        // realSWAY << params.real_SWAY << endl;
        // realHEAVE << params.real_HEAVE << endl;
        // realROLL_RATE << params.real_roll_rate << endl;
        // realPITCH_RATE << params.real_pitch_rate << endl;
        // realYAW_RATE << params.real_yaw_rate << endl;
        // ROLL << muy(0) << endl;
        // PITCH << muy(0) << endl;
        // YAW << muy(0) << endl;

       //assert(0);
        // This calls the dynamics function in this script
        //mainObj.boatDynamics(x, f1);
        //measUpdate_UKF();


        //timeUpdateContinuous should actually call unscentedTransform (or maybe measUpdate from gaussian.hpp)
        // std::cout << "Muy: " << muy << std::endl;
        // std::cout << "Syy: " << Syy << std::endl;




       
//        Eigen::VectorXd ENU = gps_posMeasurementModel(xp, dx, origin_lat, origin_long, origin_alt,latitude,longitude,altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);
//        Eigen::VectorXd velocity = gps_velMeasurementModel(xp, dx, latitude,longitude,altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz);
//        AccMeasurementModel(xp, dx, latitude,longitude,altitude, roll, pitch, yaw, velocity[0], velocity[1], velocity[2], accx, accy, accz);
//        GyroMeasurementModel(xp, dx, ENU[0], ENU[1], ENU[2], roll, pitch, yaw, velocity[0], velocity[1], velocity[2], accx, accy, accz);
       
       
        //MagMeasurementModel(x,dx);
        //mainObj.boatDynamics(count,x); 
        //^^^^^Will need this once ODE45 working


//THINK I NEED TO DO FUNCTION HANDLE OR SOMETHING HERE TO MAKE ALL MEASUREMENT MODELS GIVE VALUE h
//        measurementUpdateUKF(x,S,pm,h,xp,Sp);


        std::cout << "---------------------------------END OF WHILE LOOP " << endl;


        loop_rate.sleep();
        if (++count >= SYS_ID_NUM_TIMESTEPS) {
        break;
        }

        x = xp; //xp -> dx     when doing measUpdate maybe
        S = Sp;
        x = muy; 
        S = Syy;
    }

    return;
}


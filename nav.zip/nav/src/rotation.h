// eulerRotation
#include <Eigen/Core>
#ifndef ROTATION_H
#define ROTATION_H
Eigen::Matrix3d Rx(Eigen::VectorXd eta);

Eigen::Matrix3d Ry(Eigen::VectorXd eta);

Eigen::Matrix3d Rz(Eigen::VectorXd eta);

Eigen::Matrix3d R(Eigen::VectorXd eta);

#endif

#include <iostream>
#include "stateEstimator.h"
#include "rotation.h"
void MagMeasurementModel(const Eigen::VectorXd & x, const boatParameters params,Eigen::VectorXd & mag_out, Eigen::MatrixXd & SR);
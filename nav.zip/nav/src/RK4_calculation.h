// eulerKDE
#include <Eigen/Dense>

//MAKE SURE TO ADD THE HEADER FILE TO MAIN.CPP AND DOUBLE CHECK MAKEFILE

/*
template <typename Func>
void affineTransform(
    const Eigen::VectorXd       & mux,      // Input
    const Eigen::MatrixXd       & Sxx,      // Input
    Func                            h,      // Model
    Eigen::VectorXd             & muy,      // Output
    Eigen::MatrixXd             & Syy       // Output
    )
{


 //6 is the length of the state
        Eigen::VectorXd    x(6), dw(6), f1, f2, f3, f4;
        double dt;

        x       = dx.head(6);
        dw      = dx.tail(6);

        func(                   x, f1);

        // Check that the output works for the first instance
        assert(f1.size()>0);
        assert(f1.cols()==1);
        assert(f1.rows()==nx);

        func(  x + (f1*dt + dw)/2, f2);
        func(  x + (f2*dt + dw)/2, f3);
        func(     x + f3*dt + dw,  f4);

        xnext   = x + (f1 + 2*f2 + 2*f3 + f4)*dt/6 + dw;
}
*/
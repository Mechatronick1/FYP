// eulerKinematicTransformation
#include <Eigen/Dense>

#ifndef EULERKINEMATICTRANSFORMATION_H
#define EULERKINEMATICTRANSFORMATION_H

#include "rotation.h"
#include "eulerKDE.h"


Eigen::MatrixXd J(Eigen::VectorXd eta)
{

    Eigen::MatrixXd J(6, 6);
    J.topLeftCorner(3, 3) = R(eta);
    J.topRightCorner(3, 3) = Eigen::Matrix3d::Zero(3, 3);
    J.bottomLeftCorner(3, 3) = Eigen::Matrix3d::Zero(3, 3);
    J.bottomRightCorner(3, 3) = TK(eta[0], eta[1]);
    return J;
}
#endif
#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include <eigen3/Eigen/Dense>
#include "gps_posMeasurementModel.hpp"
#include "stateEstimator.h"
#include "WGS84toCartesian.hpp"
#include "peridetic.h"
#include "gnss_tf.hpp"
#include <random>
#include <math.h>

double a = 6378137.0;
double b = 6356752.314245;
double f = (a - b) / a;
double e_sq = f * (2 - f);

 void gps_posMeasurementModel(const Eigen::VectorXd & x, const boatParameters params, Eigen::VectorXd & ENU, Eigen::MatrixXd & SR){
std::cout << "--------Start of GPS position--------" << std::endl;
double sigmar_V = 2.0; //vertical (north) position noise [m]
double sigmar_H = 0.85; //horizontal (east) position noise [m]

///////////////////////////////////////MAY NEED TO ADD ALTITUDE TO THE NOISE MEASUREMENT THING AT THE BOTTOM OF THIS FUNCTION

//mainClass mainObj;

//ros::spinOnce();
    // std::cout << "Latitude dragged into function \n" << latitude << std::endl;
    // std::cout << "Longitude dragged into function \n" << longitude << std::endl;
    // std::cout << "Altitude dragged into function \n" << altitude << std::endl;

    // std::cout << "origin lat" << origin_lat << std::endl;
    // std::cout << "origin long" << origin_long << std::endl;
    // std::cout << "otigin alt" << origin_alt << std::endl;

    //DONE ---- change sigma horizontal and vertical - check matlab
    //add noise to lat,long altitude - simulate measurement model
    //change to body fixed
   
        Eigen::MatrixXd calc(3,3);
            calc <<
                0.7225, 0, 0,
                0, 0.7225, 0,
                0, 0, 4.0;
        //Finding the cholesky decomposition
        SR = calc.llt().matrixL();

        std::cout << "SR: " << SR << std::endl;

        
        ////////////////////////////////// NEED TO ADD VALUES TO STATES-----------------CHECK PHOTOS
        Eigen::MatrixXd rMCb(3,1);
            rMCb <<
                0, //+0.85*cos(yaw) ------ NORTH......switch this with east so we are in ENU
                0 + 0.85, //*sin(yaw) ---- EAST.......switch this with north so we are in ENU
                0 - 1.3;  // --------------UP



        // Check GyroMeasurementModel for comments about needing to double check to ensure this matrix is correct
        Eigen::MatrixXd Rbm(3,3);
            Rbm <<
                1,0,0,
                0,1,0,
                0,0,1;
        
        
        //eta
        // Eigen::VectorXd eta(6);
        // eta << x(0),
        //        x(1),
        //        x(2),
        //        x(3),
        //        x(4),
        //        x(5); 
        

//Getting noise values between -1 and 1 (which is std of 1) - COULD BE BETTER, SEEMS TO REPEAT SAME NUMBERS
    // float random = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    // float random1 = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    // float random2 = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    // std::cout << "random value \n" << random << std::endl;
    // std::cout << "random value \n" << random1 << std::endl;
    // std::cout << "random value \n" << random2 << std::endl;
    // Eigen::VectorXd rand(3,1);
    // rand << random,
    //         random1,
    //         random2;

        // Eigen::MatrixXd h(2,1);
        // h << eta(0),
        //      eta(1);
        // std::cout << "h: " << h << std::endl;

    Eigen::VectorXd h(3);
    h <<    params.latitude,
            params.longitude,
            params.altitude;


        double lambda0 = h[0] * (M_PI / 180);
        double phi0 = h[1] * (M_PI / 180);
        double s0 = sin(lambda0);
        double N0 = a / sqrt(1 - e_sq * s0 * s0);

        double sin_lambda0 = sin(lambda0);
        double cos_lambda0 = cos(lambda0);
        double cos_phi0 = cos(phi0);
        double sin_phi0 = sin(phi0);

        //Cartesian coordinates
        double x_car = (h[2] + N0) * cos_lambda0 * cos_phi0;
        double y_car = (h[2] + N0) * cos_lambda0 * sin_phi0;
        double z_car = (h[2] + (1 - e_sq) * N0) * sin_lambda0;



        double lambda = params.origin_lat * (M_PI/180) ;
        double phi = params.origin_long * (M_PI/180);
        double s = sin(lambda);
        double N = a / sqrt(1 - e_sq * s * s);

        double sin_lambda = sin(lambda);
        double cos_lambda = cos(lambda);
        double cos_phi = cos(phi);
        double sin_phi = sin(phi);

        double x0 = (params.origin_alt + N) * cos_lambda * cos_phi;
        double y0 = (params.origin_alt + N) * cos_lambda * sin_phi;
        double z0 = (params.origin_alt + (1 - e_sq) * N) * sin_lambda;

        double xd = x_car - x0;
        double yd = y_car - y0;
        double zd = z_car - z0;

        // Matrix multiplication
        double xEast = (-sin_phi * xd) + (cos_phi * yd);
        double yNorth = ((-cos_phi * sin_lambda) * xd) - ((sin_lambda * sin_phi) * yd) + (cos_lambda * zd);
        double zUp = ((cos_lambda * cos_phi) * xd) + ((cos_lambda * sin_phi) * yd) + (sin_lambda * zd);

    
    ENU.resize(3);
    ENU(0) = xEast;
    ENU(1) = yNorth;
    ENU(2) = zUp;


    
//////////////////////NEED TO SLAP SOME NOISE ON HERE FOR ALL MEASUREMENT MODELS





//return ENU, SR;   //y is a vector of [East,North,Up]

}
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// //     double lla[3] = {y[0],y[1],y[2]};
// //     double ref_lla[3] = {-33.7228, 150.674, 1.12966};
// //     double enu[3];
// //     double xyz[3];
// //     double ref_xyz[3];

// //     double A_EARTH = 6378137.0;
// // 	double flattening = 1.0/298.257223563;
// // 	double NAV_E2 = (2.0-flattening)*flattening; // also e^2
// // 	double deg2rad = M_PI/180.0;

// // 	double slat = sin(lla[0]*deg2rad);
// // 	double clat = cos(lla[0]*deg2rad);
// // 	double r_n = A_EARTH/sqrt(1.0 - NAV_E2*slat*slat);
// // 	xyz[0] = (r_n + lla[2])*clat*cos(lla[1]*deg2rad);  
// // 	xyz[1] = (r_n + lla[2])*clat*sin(lla[1]*deg2rad);  
// // 	xyz[2] = (r_n*(1.0 - NAV_E2) + lla[2])*slat;

// //     double slat1 = sin(ref_lla[0]*deg2rad);
// // 	double clat1 = cos(ref_lla[0]*deg2rad);
// // 	double r_n1 = A_EARTH/sqrt(1.0 - NAV_E2*slat1*slat1);
// // 	ref_xyz[0] = (r_n1 + ref_lla[2])*clat1*cos(ref_lla[1]*deg2rad);  
// // 	ref_xyz[1] = (r_n1 + ref_lla[2])*clat1*sin(ref_lla[1]*deg2rad);  
// // 	ref_xyz[2] = (r_n1*(1.0 - NAV_E2) + ref_lla[2])*slat1;

// //     double diff_xyz[3],R[3][3];
	
// //     //Difference xyz from reference point
// //     diff_xyz[0] = xyz[0] - ref_xyz[0];
// //     diff_xyz[1] = xyz[1] - ref_xyz[1];
// //     diff_xyz[2] = xyz[2] - ref_xyz[2];



// //     rot3d(R, ref_lla[0], ref_lla[1]);
// //     matrixMultiply(enu,R,diff_xyz);
// // }

// // void rot3d(double R[3][3], const double reflat, const double reflon){

// //     double R1[3][3],R2[3][3];

// //     rot(R1, 90 + reflon, 3);
// //     rot(R2, 90 - reflat, 1);
// // }

// // void rot(double R[3][3], const double angle, const int axis) {

// //     double cang = cos(angle * M_PI / 180);
// //     double sang = sin(angle * M_PI / 180);

// //     if (axis == 1) {
// //         R[0][0] = 1;
// //         R[0][1] = 0;
// //         R[0][2] = 0;
// //         R[1][0] = 0;
// //         R[2][0] = 0;
// //         R[1][1] = cang;
// //         R[2][2] = cang;
// //         R[1][2] = sang;
// //         R[2][1] = -sang;
// //     } else if (axis == 2) {
// //         R[0][1] = 0;
// //         R[1][0] = 0;
// //         R[1][1] = 1;
// //         R[1][2] = 0;
// //         R[2][1] = 0;
// //         R[0][0] = cang;
// //         R[2][2] = cang;
// //         R[0][2] = -sang;
// //         R[2][0] = sang;
// //     } else if (axis == 3) {
// //         R[2][0] = 0;
// //         R[2][1] = 0;
// //         R[2][2] = 1;
// //         R[0][2] = 0;
// //         R[1][2] = 0;
// //         R[0][0] = cang;
// //         R[1][1] = cang;
// //         R[1][0] = -sang;
// //         R[0][1] = sang;
// //     }
// // }

// // void matrixMultiply(double C[3][3], const double A[3][3], const double B[3][3]){

// //     C[0][0] = A[0][0] * B[0][0] + A[0][1] * B[1][0] + A[0][2] * B[2][0];
// //     C[0][1] = A[0][0] * B[0][1] + A[0][1] * B[1][1] + A[0][2] * B[2][1];
// //     C[0][2] = A[0][0] * B[0][2] + A[0][1] * B[1][2] + A[0][2] * B[2][2];
// //     C[1][0] = A[1][0] * B[0][0] + A[1][1] * B[1][0] + A[1][2] * B[2][0];
// //     C[1][1] = A[1][0] * B[0][1] + A[1][1] * B[1][1] + A[1][2] * B[2][1];
// //     C[1][2] = A[1][0] * B[0][2] + A[1][1] * B[1][2] + A[1][2] * B[2][2];
// //     C[2][0] = A[2][0] * B[0][0] + A[2][1] * B[1][0] + A[2][2] * B[2][0];
// //     C[2][1] = A[2][0] * B[0][1] + A[2][1] * B[1][1] + A[2][2] * B[2][1];
// //     C[2][2] = A[2][0] * B[0][2] + A[2][1] * B[1][2] + A[2][2] * B[2][2];

// // }

// // void matrixMultiply(double c[3], const double A[3][3], const double b[3]){

// //     c[0] = A[0][0] * b[0] + A[0][1] * b[1] + A[0][2] * b[2];
// //     c[1] = A[1][0] * b[0] + A[1][1] * b[1] + A[1][2] * b[2];
// //     c[2] = A[2][0] * b[0] + A[2][1] * b[1] + A[2][2] * b[2];


// //     std::cout << "North = " << c[0] << std::endl;
// //     std::cout << "East = " << c[1] << std::endl;
// //     std::cout << "Up = " << c[2] << std::endl;
// // }


// //Fill out eta/nu with local lat,long alt, etc......... in gyro and acc measurement models


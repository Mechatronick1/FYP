#include <iostream>
#include "stateEstimator.h"
Eigen::VectorXd simulateMeasurement_gps_pos(Eigen::VectorXd & x, Eigen::VectorXd & dx, boatParameters params);

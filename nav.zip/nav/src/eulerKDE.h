// eulerKDE
#include <Eigen/Dense>

Eigen::Matrix3d TK(double a, double b)
{
	Eigen::Matrix3d TK;
	TK << 1, sin(a) * tan(b), cos(a) * tan(b),
		  0,		cos(a),			-sin(a),
		  0, sin(a) / cos(b), cos(a) / cos(b);
	return TK;
}
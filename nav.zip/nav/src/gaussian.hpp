#ifndef GAUSSIAN_HPP
#define GAUSSIAN_HPP

#define _USE_MATH_DEFINES
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846264338327950288
#endif
#include <cassert>
#include <functional>
#include <Eigen/Core>
#include <Eigen/QR>
#include <Eigen/Eigenvalues> 
#include "stateEstimator.h"

void pythagoreanQR(const Eigen::MatrixXd& S1, const Eigen::MatrixXd& S2, Eigen::MatrixXd& S);
void conditionGaussianOnMarginal(const Eigen::VectorXd & muyxjoint, const Eigen::MatrixXd & Syxjoint, const Eigen::VectorXd & y, Eigen::VectorXd & muxcond, Eigen::MatrixXd & Sxcond);
void gaussianConfidenceEllipse3Sigma(const Eigen::VectorXd & mu, const Eigen::MatrixXd & S, Eigen::MatrixXd & x);
void gaussianConfidenceQuadric3Sigma(const Eigen::VectorXd &mu, const Eigen::MatrixXd & S, Eigen::MatrixXd & Q);



using namespace std;
using namespace Eigen;


// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// logGaussian
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------

template <typename Scalar>
Scalar logGaussian(const Eigen::Matrix<Scalar,Eigen::Dynamic,1> &x,
                   const Eigen::Matrix<Scalar,Eigen::Dynamic,1> &mu,
                   const Eigen::Matrix<Scalar,Eigen::Dynamic,Eigen::Dynamic> &S)
{
    assert(x.cols() == 1);
    assert(mu.cols() == 1);
    assert(x.size() == mu.size());
    assert(S.rows() == S.cols());
    assert(S.rows() == x.size());

    // Compute log N(x;mu,P) where P = S.'*S
    // log N(x;mu,P) = -0.5*(x - mu).'*inv(P)*(x - mu) - 0.5*log(det(2*pi*P))

    // TODO: Copy from Lab 6
    using std::log;
    using std::sqrt;
    using std::exp;
    int n = x.rows();
    // S.template triangularView<Eigen::Upper>()
    Eigen::Matrix<Scalar, Eigen::Dynamic, Eigen::Dynamic> Z = S.template triangularView<Eigen::Upper>().transpose().solve((x - mu));// .squaredNorm();
    Scalar sum = S.diagonal().array().abs().log().sum();

    return -0.5 * Z.squaredNorm() - 0.5 * n * log(2 * M_PI) - sum;
    
}

template <typename Scalar>
Scalar logGaussian(const Eigen::Matrix<Scalar,Eigen::Dynamic,1> &x,
                   const Eigen::Matrix<Scalar,Eigen::Dynamic,1> &mu,
                   const Eigen::Matrix<Scalar,Eigen::Dynamic,Eigen::Dynamic> &S,
                   Eigen::Matrix<Scalar,Eigen::Dynamic,1> &g)
{
    // Compute gradient of log N(x;mu,P) w.r.t x, -S\S.'\(x-u) 
    // note::where inverse, use solve
    g = -S.template triangularView<Eigen::Upper>().solve(S.template triangularView<Eigen::Upper>().transpose().solve(x - mu));
    return logGaussian(x, mu, S);
}

template <typename Scalar>
Scalar logGaussian(const Eigen::Matrix<Scalar,Eigen::Dynamic,1> &x,
                   const Eigen::Matrix<Scalar,Eigen::Dynamic,1> &mu,
                   const Eigen::Matrix<Scalar,Eigen::Dynamic,Eigen::Dynamic> &S,
                   Eigen::Matrix<Scalar,Eigen::Dynamic,1> &g,
                   Eigen::Matrix<Scalar,Eigen::Dynamic,Eigen::Dynamic> &H)
{

    //cout << "S is" << S.rows() << endl;
    //cout << "mu is" << mu.rows() << endl;
    //cout << "x is" << x << endl;

    //g = -S.template triangularView<Upper>().solve(S.template triangularView<Upper>().transpose().solve(x - mu));
    //g = S.triangularView<Upper>().solve(S.triangularView<Upper>().transpose().solve(x - mu));
    //cout << "g is" << g << endl;
    
    // Compute Hessian of log N(x;mu,P) w.r.t x -S\S.'\*I
    // note::where inverse, use solve
    H = -S.template triangularView<Eigen::Upper>().solve(S.template triangularView<Eigen::Upper>().transpose().solve(Eigen::Matrix<Scalar, Eigen::Dynamic, Eigen::Dynamic>::Identity(S.rows(), S.cols())));  
    //cout << "h is" << H << endl;
    
    return logGaussian(x, mu, S, g);
}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// affineTransform
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
template <typename Func>
/////////////unscented - change
void affineTransform(
    const Eigen::VectorXd       & mux,      // Input
    const Eigen::MatrixXd       & Sxx,      // Input
    Func                            h,      // Model
    Eigen::VectorXd             & muy,      // Output
    Eigen::MatrixXd             & Syy       // Output
    )
{
    assert(mux.size()>0);
    assert(mux.cols() == 1);

    //std::cout << "Sxx: " << Sxx << endl;
    //std::cout << "mux: " << mux << endl;
    assert(Sxx.cols() == Sxx.rows());
    assert(mux.rows() == Sxx.rows());



    // Transform function
    MatrixXd SR, C;
    h(mux, muy, SR, C);

    // Check outputs of h using the assert function
    //std::cout << "muy: " << muy << endl;
    //std::cout << "SR: " << SR << endl;
    // Check SR is square and same rows as input muy
    assert(SR.rows() == muy.rows());
    assert(SR.cols() == SR.rows());

    

    // Check J has same rows as muy and cols as mux
   // assert(C.rows() == muy.rows());
   // assert(C.cols() == mux.rows());


    // Prepare variables for pythagorean QR
    MatrixXd SJ = Sxx;

    //std::cout << "SJ: " << SJ << endl;
    //std::cout << "SR: " << SR << endl;

    // Send to pythagorean QR function from lab 4
   // pythagoreanQR(SR, SJ, Syy);

    // Check the dimentions of Syy, make sure equal to SR and square matrix
    //assert(Syy.rows() == Syy.cols());
   // assert(Syy.cols() == SR.cols());
   // assert(Syy.rows() == SR.rows());
    
    //cout << "mux" << mux << endl;
    //cout << "Sxx" << Sxx << endl;
   // cout << "C" << C << endl;
    // check that they are all greater than 0 and for NaNs?
    assert(SR.size() > 0);
   // assert(C.size() > 0);
   // assert(Syy.size() > 0);
    //assert(!Syy.hasNaN());

}


template <typename Func>
/////////////unscented - change
void unscentedTransform(
    const Eigen::VectorXd       & mux,      // Input
    const Eigen::MatrixXd       & Sxx,      // Input
    Func                            h,      // Model
    Eigen::VectorXd             & muy,      // Output
    Eigen::MatrixXd             & Syy       // Output
    )
{
   // unscented simple code....
//std::cout << "mux: " << mux << std::endl; //States coming in
//std::cout << "Sxx: " << Sxx << std::endl; //Covariance coming in
//std::cout << "muy: " << muy << std::endl;
//std::cout << "Syy: " << Syy << std::endl;


int n = Sxx.cols();
int nsigma = n*2;
//std::cout << "n: " << n << std::endl;

double timestep = 0.1;

    Eigen::MatrixXd sP = Eigen::MatrixXd::Zero(n,n);
    sP = Sxx.llt().matrixL().transpose();
   // std::cout << "sp: " << sP << std::endl;

    // Eigen::MatrixXd sP(12,12);
    // sP << temp_sP.transpose();
    //     std::cout << "sP: " << sP << std::endl;

    Eigen::MatrixXd p = Eigen::MatrixXd::Zero(n,n);
    p << sqrt(n)*sP;
   // std::cout << "p: " << p << std::endl;


    // Eigen::MatrixXd mumat(12,12);
    //     mumat << mux; 

   // std::cout << "mux: " << mux << std::endl;
    Eigen::MatrixXd si = Eigen::MatrixXd::Zero(n,n);
    si << p;
   // std::cout << "si: " << si << std::endl;
    si = si.colwise()+mux;


    //Matrix size may need to change at some point but for now should be ok as 12,24
    Eigen::MatrixXd s = Eigen::MatrixXd::Zero(n,nsigma);
    s << si, (-1.0*p).colwise()+mux;
   // std::cout << "s: \n" << s << std::endl;


    // Eigen::MatrixXd y(n/2,nsigma);
    // y = MatrixXd::Zero(n/2,nsigma);
    // Eigen::MatrixXd mutotal(n/2,1);
    // mutotal = MatrixXd::Zero(n/2,1);
    Eigen::VectorXd dx_dif = Eigen::VectorXd::Zero(n/2);
    // std::cout << "--------------------------S BEFORE ENTERING H FUNCTION----------------------------: \n" << S << std::endl;
    
    // Eigen::MatrixXd SR = Eigen::MatrixXd::Zero(n/2,n/2);
    
   // h(mux, sv, timestep, dx, SR); 
    
    // std::cout << "--------------------------S AFTER ENTERING H FUNCTION----------------------------: \n" << S << std::endl;
    Eigen::MatrixXd SQ = Eigen::MatrixXd::Zero(n,n);
    
    h(s.block(0,1,n,1), dx_dif, SQ);
    int n_dif = dx_dif.rows();
    //std::cout << "n_dif \n" << n_dif << std::endl;

    Eigen::MatrixXd ysigma = Eigen::MatrixXd::Zero(n_dif,nsigma);
    ysigma = ysigma.colwise() + dx_dif;

    Eigen::MatrixXd y(n_dif,nsigma);
    y = MatrixXd::Zero(n_dif,nsigma);
    Eigen::MatrixXd mutotal(n_dif,1);
    mutotal = MatrixXd::Zero(n_dif,1);
    Eigen::VectorXd dx = Eigen::VectorXd::Zero(n_dif);
    Eigen::MatrixXd SR = Eigen::MatrixXd::Zero(n_dif,n_dif);
    for (int i = 0; i < 2*n; i++){

        //JUST WROTE THIS ONE
    //std::cout << "s block \n" << s.block(0,i,n,1) << std::endl;

    Eigen::MatrixXd SQ = Eigen::MatrixXd::Zero(n,n);

    Eigen::VectorXd sv = Eigen::VectorXd::Zero(n);
    sv << s.block(0,i,n,1);
    //std::cout << "sv \n" << sv << std::endl;

    BoatDynamics pm;//////////////////////////NEED THIS HERE OTHERWISE IT ERRORS
    //pm(sv, muy);
    //THIS WAS H, WHEN IT WAS CLOSE TO WORKING
    
    h(sv, dx, SQ);
    //std::cout << "dx trying: " << dx << std::endl;

    //std::cout << "y trying: " << y << std::endl;
    
    //Setting value of muy
    y.block(0,i,n_dif,1) = dx;
    //y.block(0,i,12,1) = muy;

    //std::cout << "-------------PRINTING DX FROM UNSCENTED TRANSFORM----------" << dx << std::endl;
    }

    ////////check boatdynamics where y (noises are changed)

/////////////GOING TO NEED TO PRINT OUT Y AND SEE WHERE THE ISSUE STARTS
/////////////NEED TO ALSO LOOK FOR ANYWHERE THAT APPLIES CALCULATIONS OR DEALS WITH Y IN ANYWAY

    //std::cout << "Muy trying: " << y << std::endl;

    for (int j = 0; j < n_dif; j++){

        //std::cout << "y block \n" << y.block(j,0,1,24).sum() << endl;

        mutotal.block(j,0,1,1) << y.block(j,0,1,nsigma).sum();

        //std::cout << "mutotal block after: \n" << mutotal.block(j,0,1,1) << endl;

    }
    
    Eigen::VectorXd average(n_dif,1);
    average << mutotal/(nsigma);

    muy = average;
    //std::cout << "muy finished value: \n" << muy << endl;

    // Eigen::VectorXd holder(12,1);
    // si = y.colwise()-muy;
 
    // std::cout << "y: " << y << std::endl;
    // std::cout << "muy: " << muy << std::endl;
    // std::cout << "nsigma: " << nsigma << std::endl;


    Syy.resize(n_dif,n_dif);
    Syy = ((y.colwise()-muy)*(y.colwise()-muy).transpose())/(nsigma);

    //std::cout << "Syy finished value: \n" << Syy << endl;
    
    std::cout << "-----------------------WHERE DOES IT GO FROM HERE???????????????????????????????????????? \n" << endl;

    //Need to do rowwise/colwise subtraction
    //Syy = (y - muy)*(y - muy).transpose()/(2*n);
    
    //fcn is model (h) i think
    //week 6 ekf ukf
    //page 67
    //Mean and covariance and pass through function and taking average is essentially what its doing
    //
}









// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// Augment Gradients
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
template <
    typename ProcessFunc
>
void augmentGradients(ProcessFunc func, const Eigen::MatrixXd & X, Eigen::MatrixXd & dX)
{
    assert(X.size()>0);
    int nx          = X.rows();
    assert(X.cols()==(2*nx + 1));

    Eigen::VectorXd x, f;
    Eigen::MatrixXd SQ(12,12), Jx(12,12);
    x               = X.col(0);

    func(x, f, SQ, Jx);
    //std::cout << "F: " << f << endl;
    //std::cout << "nx: " << nx << endl;
    assert(f.rows()==nx);


    assert(SQ.rows()==nx);
    assert(Jx.rows()==nx);

    dX.resize(nx, 2*nx + 1);
    dX << f, Jx*X.block(0, 1, nx, 2*nx);
}


// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// RK4SDEHelper
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
template <
    typename ProcessFunc
>
struct RK4SDEHelper
{
    void operator()(ProcessFunc func, const Eigen::VectorXd & xdw, double dt, Eigen::VectorXd &xnext)
    {
        
        // Check that dimension of augmented state is even
        assert(xdw.size()>0);
        assert(xdw.size() % 2 == 0);
        int nx  = xdw.size()/2;
        Eigen::VectorXd    x(nx), dw(nx), f1, f2, f3, f4;

        x       = xdw.head(nx);
        dw      = xdw.tail(nx);
//std::cout << "x \n" << x << endl;
        func(                   x, f1);
   // std::cout << "f1 \n" << f1 << endl;
        // Check that the output works for the first instance
        assert(f1.size()>0);
        assert(f1.cols()==1);
        assert(f1.rows()==nx);

        func(  x + (f1*dt + dw)/2, f2);
  //     std::cout << "f2 \n" << f2 << endl;
        func(  x + (f2*dt + dw)/2, f3);
  //      std::cout << "f3 \n" << f3 << endl;
        func(     x + f3*dt + dw,  f4);
  //      std::cout << "f4 \n" << f4 << endl;
  //      cout << "dw : " << dw << endl;
        xnext   = x + (f1 + 2*f2 + 2*f3 + f4)*dt/6 + dw;

  //      cout << "xnext : " << xnext << endl;
  //      cout << "xdw : " << xdw << endl;
        
    }
    void operator()(ProcessFunc func, const Eigen::VectorXd & xdw, double dt, Eigen::VectorXd &xnext, Eigen::MatrixXd  &SR)
    {
        assert(xdw.size() > 0);
        assert(xdw.size() % 2 == 0);
    
        int nx  = xdw.size();
        SR      = Eigen::MatrixXd::Zero(nx, nx);
        operator()(func, xdw, dt, xnext);

    }
    void operator()(ProcessFunc func, const Eigen::VectorXd & xdw, double dt, Eigen::VectorXd &xnext, Eigen::MatrixXd  &SR, Eigen::MatrixXd &J)
    {
        assert(xdw.size() > 0);
        assert(xdw.size() % 2 == 0);
        int nxdx    = xdw.size();
        int nx      = nxdx/2;
        Eigen::VectorXd    x(nx), dw(nx);

        x       = xdw.head(nx);
        dw      = xdw.tail(nx);

        typedef Eigen::MatrixXd Matrix;

        Matrix X(nx, nxdx+1),  dW(nx, nxdx+1);
        X   <<  x, Matrix::Identity(nx, nx),    Matrix::Zero(nx, nx);
        dW  << dw, Matrix::Zero(nx, nx),        Matrix::Identity(nx, nx);
    
        Matrix F1, F2, F3, F4, Xnext;
        augmentGradients(func,                  X, F1);
        augmentGradients(func, X + (F1*dt + dW)/2, F2);
        augmentGradients(func, X + (F2*dt + dW)/2, F3);
        augmentGradients(func,     X + F3*dt + dW, F4);

        Xnext       = X + (F1 + 2*F2 + 2*F3 + F4)*dt/6 + dW;
        xnext       = Xnext.col(0);
        J           = Xnext.block(0, 1, nx, 2*nx);
        SR          = Matrix::Zero(nx, nx);
    }
};

// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// AugmentIdentityAdapter
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
template <
    typename Func, 
    typename ParamStruct
>
struct AugmentIdentityAdapter
{
    void operator()(Func h, const Eigen::VectorXd & x, const ParamStruct param, Eigen::VectorXd & yx)
    {
        assert(x.size()>0);

        Eigen::VectorXd y;
        h(x, param, y);
        assert(y.size()>0);
        
        int nx  = x.size();
        int ny  = y.size();
        int nyx = ny + nx;
        
        yx.resize(nyx);

        yx.head(ny)                 = y;
        yx.tail(nx)                 = x;
    }

    void operator()(Func h, const Eigen::VectorXd & x, const ParamStruct param, Eigen::VectorXd & yx, Eigen::MatrixXd  & SRR)
    {
        assert(x.size()>0);

        Eigen::VectorXd y;
        Eigen::MatrixXd SR;

        h(x, param, y, SR);
        assert(y.size()>0);
        assert(SR.size()>0);

        int nx  = x.size();
        int ny  = y.size();
        int nyx = nx + ny;

        SRR.resize(nyx, nyx);
        yx.resize(nyx);

        yx.head(ny)                 = y;
        yx.tail(nx)                 = x;

        SRR.fill(0);
        SRR.topLeftCorner(ny, ny)   = SR;      

    }

    void operator()(Func h, const Eigen::VectorXd & x, const ParamStruct param, Eigen::VectorXd & yx, Eigen::MatrixXd  & SRR, Eigen::MatrixXd & CI)
    {
    //     assert(x.size()>0);

    //     Eigen::VectorXd y;
    //     Eigen::MatrixXd SR;
    //     Eigen::MatrixXd C;

    //     h(x, param, y, SR, C);
    //     assert(y.size()>0);
    //     assert(SR.size()>0);
    //     assert(C.size()>0);
        
    //     int nx                      = x.size();
    //     int ny                      = y.size();
    //     int nyx                     = nx + ny;
            
    //     CI.resize(nyx, nx);
    //     SRR.resize(nyx, nyx);
    //     yx.resize(nyx);

    //     yx.head(ny)                 = y;
    //     yx.tail(nx)                 = x;

    //     SRR.fill(0);
    //     SRR.topLeftCorner(ny, ny)   = SR;

    //     CI.fill(0);
    //     CI.topLeftCorner(ny, nx)    = C;
    //     CI.bottomLeftCorner(nx, nx) = Eigen::MatrixXd::Identity(nx, nx);
    }
};


// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// timeUpdateContinuous
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
template <typename ProcessFunc>
void timeUpdateContinuous(
    const Eigen::VectorXd   & mukm1,    // Input
    const Eigen::MatrixXd    & Skm1,    // Input
    //const Eigen::VectorXd       & u,    // Input
    ProcessFunc                  pm,    // Process model
    boatParameters             & param,    // Model parameters
    double                 timestep,    // Time step
    Eigen::VectorXd           & muk,    // Output
    Eigen::MatrixXd            & Sk     // Output
    )
{
 //cout << "Skm1 start: " << Skm1 << endl;

//-----------------------------mukm1 and skm1 are coming in here as 12
    // Noise mean
    assert(mukm1.size()>0);
    Eigen::VectorXd muxdw(2*mukm1.size());
    muxdw.fill(0.);
    muxdw.head(mukm1.size())    = mukm1;
 //   cout << "Muxdw: " << muxdw << endl;
    //cout << "mukm1: " << mukm1 << endl;
//cout << "Skm1 start: " << Skm1 << endl;

    //Noise covariance
    Eigen::VectorXd  f;
    Eigen::MatrixXd  SQ = Eigen::MatrixXd::Zero(12,12);
    cout << "printing before call to boatdyanmics: " << endl;
    pm(mukm1, f, SQ); 
    
//cout << "mukm1: " << mukm1 << endl;

    assert(f.size()>0);
    assert(SQ.size()>0);

    //----------------------------------------------NEED TO ADD IN CALL TO RUNGE-KUTTA HERE
 //   cout << "SQ: " << SQ << endl;
 //   cout << "---------------------------------STARTING RK4 SDE HELPER------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ " << endl;
    // auto h  = std::bind(func, pm, std::placeholders::_1, timestep, std::placeholders::_2, std::placeholders::_3);

////////-------THINK THERE IS A SIZING ISSUE HERE WITH MATRIX---------


//cout << "mukm1: " << mukm1 << endl;
//cout << "Muxdw: " << muxdw << endl;
//cout << "skm1: " << Skm1 << endl;

    Eigen::MatrixXd Sxdw(24, 24);
    Sxdw.topLeftCorner(12, 12) = Skm1;
    Sxdw.topRightCorner(12, 12) = Eigen::MatrixXd::Zero(12, 12);
    Sxdw.bottomLeftCorner(12, 12) = Eigen::MatrixXd::Zero(12, 12);
    Sxdw.bottomRightCorner(12, 12) = SQ*sqrt(timestep);

    //cout << "Sxdw: " << Sxdw << endl;

    Eigen::VectorXd dx;
    Eigen::MatrixXd SR;
    RK4SDEHelper<ProcessFunc> func;
   //auto h  = std::bind(func, pm, muxdw, timestep, dx, SR); 

 auto h  = std::bind(func, pm, std::placeholders::_1, timestep, std::placeholders::_2,std::placeholders::_3);
// std::cout << "Sxdw: \n" << Sxdw << std::endl;

//blk.topLeftCorner(Skm1.rows(),Skm1.cols())=Skm1;

//cout << "Skm1 transformed \n" <<  << endl;

    //cout << "muxGy: " << mukm1 << endl;

// Noise covariance
   
    // RK4SDEHelper::operator()(func, xdw, u, param, dt, f, SR, J)
    // https://www.cplusplus.com/reference/functional/bind/

    //cout << "muxGy: " << muxdw << endl;
     


   // cout << "Before Unscented transform: " << mukm1 << endl;

    //Previously had h instead of pm
    unscentedTransform(muxdw, Sxdw, h, muk, Sk);
   
}


// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// measurementUpdateUKF
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
template <typename Func, typename ParamStruct>
//change e to u
void measurementUpdateUKF(
    const Eigen::VectorXd       & mux,      // Input
    const Eigen::MatrixXd       & Sxx,      // Input
    //const Eigen::VectorXd         & xp,      // Input
    const Eigen::VectorXd         & y,      // Input ------this is from simulateMeasurement
    Func             measurementModel,      // Model
    const ParamStruct         & param,      // Input -----I have commented this our for now, may need to be uncommented
    Eigen::VectorXd           & muxGy,      // Output
    Eigen::MatrixXd           & SxxGy       // Output
    )
{
    assert(mux.size()>0);
    assert(Sxx.size()>0);
    assert(y.size()>0);

    AugmentIdentityAdapter<Func, ParamStruct>        aia;

    // Create joint function with the following prototype
    // jointFunc(x, h, SR, H)
    auto jointFunc      = std::bind(aia,
                            measurementModel,
                            std::placeholders::_1,
                            param, 
                            std::placeholders::_2,
                            std::placeholders::_3);

    
      //  std::cout << "Trying to print inside the measurementupdateUKF (X value)\n" << Sxx << std::endl;

    Eigen::VectorXd muyx = Eigen::VectorXd::Zero(12);
    Eigen::MatrixXd Syx = Eigen::MatrixXd::Zero(12, 12);
   

    //Unscented transform - change
    unscentedTransform(mux, Sxx, jointFunc, muyx, Syx); 
    
    

   // std::cout << "MUYX boi\n" << muyx << std::endl;
   // std::cout << "SYX boi" << Syx << std::endl;
   // std::cout << "Y boi" << y << std::endl;

    //--------------Doesn't like that s1 is a 3x3 matrix of 0's.
    conditionGaussianOnMarginal(muyx, Syx, y, muxGy, SxxGy); //////HAVING PROBLEMS WITH THIS LINE
    // std::cout << "MUXGY boi\n" << muxGy << std::endl;
    // std::cout << "Sxx boi" << SxxGy << std::endl;

    //std::cout << "Printing muxGy after conditiongaussian\n" << muxGy << std::endl;
    // std::cout << "Printing Sxx after conditiongaussian\n" << SxxGy << std::endl;
}

// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// measurementUpdateIEKF
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
template <
    typename LogLikFunc,
    typename ParamStruct
>
struct CostJointDensity
{
    double operator()(LogLikFunc logLikelihood, const Eigen::VectorXd& y, const Eigen::VectorXd& x, const ParamStruct& param, const Eigen::VectorXd& mu, const Eigen::MatrixXd& S)
    {
        double logprior = logGaussian(x, mu, S);
        double loglik = logLikelihood(y, x, param);
        return -(logprior + loglik);
    }

    double operator()(LogLikFunc logLikelihood, const Eigen::VectorXd& y, const Eigen::VectorXd& x, const ParamStruct& param, const Eigen::VectorXd& mu, const Eigen::MatrixXd& S, Eigen::VectorXd& g)
    {
        Eigen::VectorXd logpriorGrad(x.size());
        double logprior = logGaussian(x, mu, S, logpriorGrad);
        Eigen::VectorXd loglikGrad(x.size());
        double loglik = logLikelihood(y, x, param, loglikGrad);
        g = -(logpriorGrad + loglikGrad);
        return -(logprior + loglik);
    }

    double operator()(LogLikFunc logLikelihood, const Eigen::VectorXd& y, const Eigen::VectorXd& x, const ParamStruct& param, const Eigen::VectorXd& mu, const Eigen::MatrixXd& S, Eigen::VectorXd& g, Eigen::MatrixXd& H)
    {
        Eigen::VectorXd logpriorGrad(x.size());
        Eigen::MatrixXd logpriorHess(x.size(), x.size());
        double logprior = logGaussian(x, mu, S, logpriorGrad, logpriorHess);

        Eigen::VectorXd loglikGrad(x.size());
        Eigen::MatrixXd loglikHess(x.size(), x.size());
        double loglik = logLikelihood(y, x, param, loglikGrad, loglikHess);

        //cout << "loglik: " << loglik << endl;
        //cout << "logpri: " << logprior << endl;

        g = -(logpriorGrad + loglikGrad);
        H = -(logpriorHess + loglikHess);

        return -(logprior + loglik);
    }
};

template <typename Func, typename ParamStruct>
void measurementUpdateIEKF(
    const Eigen::VectorXd       & mux,      // Input
    const Eigen::MatrixXd       & Sxx,      // Input
    //const Eigen::VectorXd         & u,      // Input
    const Eigen::VectorXd         & y,      // Input
    Func                logLikelihood,      // Model
    const ParamStruct         & param,      // Input
    Eigen::VectorXd           & muxGy,      // Output
    Eigen::MatrixXd           & SxxGy       // Output
    )
{

    //cout << "mux: " << mux << endl;
    //cout << "Sxx: " << Sxx << endl;
    //cout << "y: " << y << endl;
    assert(mux.size()>0);

    // Create cost function with prototype 
    // V = cost(x, g, H)
    CostJointDensity<Func, ParamStruct> cjd;
    using namespace std::placeholders;
    auto costFunc = std::bind(cjd, logLikelihood, y, std::placeholders::_1, param, mux, Sxx, std::placeholders::_2, std::placeholders::_3);
    
    // Minimise cost
    Eigen::MatrixXd Q(mux.size(),mux.size());
    Eigen::VectorXd v(mux.size());
    Eigen::VectorXd g(mux.size());
    constexpr int verbosity = 0; // 0:none, 1:dots, 2:summary, 3:iter
    muxGy = mux; // Start optimisation at prior mean

    //cout << "muxGy: " << mux << endl;
    //cout << "Sxx: " << Sxx << endl;
    //cout << "y: " << y << endl;

    fminNewtonTrustEig(costFunc, muxGy, g, Q, v, verbosity);
    //cout << "Q" << Q << endl;
    //cout << "v" << v << endl;
    //cout << "Q" << Q << endl;
    // H = Q*diag(v)*Q.'
    // S.'*S = P = inv(H) = Q*diag(1./v)*Q.' = Q*diag(1./realsqrt(v))*diag(1./realsqrt(v))*Q.'
    // S = triu(qr(diag(1./realsqrt(v))*Q.'))

    SxxGy = v.cwiseSqrt().cwiseInverse().asDiagonal()*Q.transpose();
    Eigen::HouseholderQR<Eigen::Ref<Eigen::MatrixXd>> qr(SxxGy); // decomposition in place
    SxxGy = qr.matrixQR().triangularView<Eigen::Upper>();
}


template <typename Func, typename ParamStruct>
void measurementUpdateIEKFSR1(
    const Eigen::VectorXd       & mux,      // Input  
    const Eigen::MatrixXd       & Sxx,      // Input  
    //const Eigen::VectorXd       & u,      // Input  
    const Eigen::VectorXd       & y,      // Input  
    Func                        logLikelihood,      // Model  
    const ParamStruct           & param,      // Input  
    Eigen::VectorXd             & muxGy,      // Output  
    Eigen::MatrixXd             & SxxGy       // Output  
)
{
    assert(mux.size() > 0);
    Eigen::VectorXd mux_t;

    // Create cost function with prototype  
    // V = cost(x, g)  
    CostJointDensity<Func, ParamStruct> cjd;
    using namespace std::placeholders;
    auto costFunc = std::bind(cjd, logLikelihood, y, std::placeholders::_1, param, mux, Sxx, std::placeholders::_2);

    // Minimise cost  
    Eigen::MatrixXd Q(mux.size(), mux.size());
    Eigen::VectorXd v(mux.size());
    Eigen::VectorXd g(mux.size());
    constexpr int verbosity = 0; // 0:none, 1:dots, 2:summary, 3:iter  
    muxGy = mux; // Start optimisation at prior mean

    Eigen::VectorXd s(mux.size());
    s.fill(1);
    s.tail(param.numberNewTags*6) = 1 * VectorXd::Ones(param.numberNewTags*6);
    //cout << param.numberNewTags << endl;

    // Eigendecomposition of initial Hessian (inverse of prior covariance)  
    //Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> eigenH(Sxx.transpose() * s.asDiagonal() * Sxx);
    Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> eigenH(Sxx.transpose() * Sxx);

    v = eigenH.eigenvalues().cwiseInverse();
    Q = eigenH.eigenvectors();

    //cout << "v: " << v << endl;
    //cout << "Q: " << Q << endl;


    fminSR1TrustEig(costFunc, muxGy, g, Q, v, verbosity);

    // Post-calculate posterior square-root covariance from Hessian approximation  
    SxxGy = v.cwiseSqrt().cwiseInverse().asDiagonal() * Q.transpose();
    Eigen::HouseholderQR<Eigen::Ref<Eigen::MatrixXd>> qr(SxxGy); // decomposition in place  
    SxxGy = qr.matrixQR().triangularView<Eigen::Upper>();
}




#endif

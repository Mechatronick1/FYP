#include <cmath>
#include <cassert>
#include <functional>
#include <Eigen/Core>
#include <Eigen/QR>
#include <Eigen/LU> // for .determinant() and .inverse(), which you should never use
#include <iostream>
#include <sstream>
#include <string>
#ifndef M_PI
#define M_PI 3.14159265358979323846264338327950288
#endif

using namespace std;
using namespace Eigen;

// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// PythagoreanQR
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------


using namespace std;
using namespace Eigen;

void pythagoreanQR(const Eigen::MatrixXd& S1, const Eigen::MatrixXd& S2, Eigen::MatrixXd& S) {
    // S1 = SR, S2 = SJ
    // Define the matricies SA and QR
    MatrixXd SA(S1.rows() + S2.rows(), S1.cols()), QR;

    // Stack S1 and S2 to make SA
    SA << S2,
        S1;

    // Perform pythagorean QR to compute QR matrix
    Eigen::HouseholderQR<Eigen::MatrixXd> qr(SA);
    qr.compute(SA);
    QR = qr.matrixQR();

    // Use the block function to get correct part of the matrix R1
    S = QR.block(0, 0, S1.cols(), S1.rows()).triangularView<Eigen::Upper>();

}

// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// conditionGaussianOnMarginal
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------


void conditionGaussianOnMarginal(const Eigen::VectorXd& muyxjoint, const Eigen::
    MatrixXd& Syxjoint, const Eigen::VectorXd& y, Eigen::VectorXd& muxcond, Eigen::
    MatrixXd& Sxcond) {

    // Seperate variables to get ny and nx
    int ny = y.rows();
    std::cout << "ny \n" << ny << std::endl;
    int nmuyx = muyxjoint.rows();
    std::cout << "nmuyx \n" << nmuyx << std::endl;
    
   // std::cout << "muyxjoint \n" << muyxjoint << std::endl;
   // std::cout << "syxjoint \n" << Syxjoint << std::endl;
   // int nx = muyxjoint.rows() - ny;
   // std::cout << "syx \n" << Syxjoint << std::endl;
    // Seperate the syxjoint matrix [S1 S2; 0 S3]
    Eigen::MatrixXd S1 = Syxjoint.topLeftCorner(ny,ny);
 //   std::cout << "s1" << S1 << std::endl;
    Eigen::MatrixXd S2 = Syxjoint.topRightCorner(ny, nmuyx-ny);
 //   std::cout << "s2" << S2 << std::endl;
    Eigen::MatrixXd S3 = Syxjoint.bottomRightCorner(nmuyx-ny, nmuyx-ny);
  //  std::cout << "s3 \n" << S3 << std::endl;


    // Calculate variables using equations 7a & 7b from lab document 
    // ** square-root form using a single triangular solve ** //
    // muxcond = S2.transpose() * S1.triangularView<Upper>().transpose().solve((y - muyxjoint.head(ny)));
   
    muxcond = muyxjoint.tail(nmuyx-ny) + S2.transpose() * S1.triangularView<Upper>().solve((y - muyxjoint.head(ny)));
    Sxcond = S3;

   // muxcond = muyxjoint.head(ny);
   // Sxcond = muyxjoint.tail(nmuyx-ny);
    
    std::cout << "Finishing conditionGaussianonMarginal" << muxcond << std::endl;

}



// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------
// 
// gaussianConfidenceEllipse
// 
// --------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------

void gaussianConfidenceEllipse3Sigma(const Eigen::VectorXd & mu, const Eigen::MatrixXd & S, Eigen::MatrixXd & x){
    assert(mu.rows() == 2);
    assert(S.rows() == 2);
    assert(S.cols() == 2);

    int nsamples  = 100;

    // TODO: 
    double c = 0.9973;
    double r = 3.4394;
    double th = 2.0 * M_PI / 100.0;
    MatrixXd z(2, 100), y(2, 100);
    x.resize(2, 100);
    x.setZero();
        
    for (int i = 0; i < nsamples; i++) {
        z(0, i) = r * std::cos(th * i);
        z(1, i) = r * std::sin(th * i);
    }

    y = (S.transpose() * z);
    //cout << "gce3s mu: "<< mu << endl;
  
    for (int i = 0; i < nsamples; i++) {
        x(0, i) = mu(0) + y(0, i) ;
        x(1, i) = mu(1) + y(1, i);
    }

    assert(x.cols() == nsamples);
    assert(x.rows() == 2);
}


void gaussianConfidenceQuadric3Sigma(const Eigen::VectorXd &mu, const Eigen::MatrixXd & S, Eigen::MatrixXd & Q){
    const int nx  = 3;
    assert(mu.rows() == nx);
    assert(S.rows() == nx);
    assert(S.cols() == nx);


    // TODO: 
    //assert(0);
    Q.resize(4, 4);
    Q.setZero();
    double fi = 14.1563;
    MatrixXd z, tl, tr, bl, br, X_c(1,1);
    X_c << fi;
    z = S.triangularView<Upper>().transpose().solve(mu);


    //cout << "gcq3s X_c: " << X_c << endl;
    //cout << "gce3s z: " << z << endl;

    tl = S.triangularView<Upper>().solve(S.triangularView<Upper>().transpose().solve(MatrixXd::Identity(S.rows(), S.cols())));
    tr = -S.triangularView<Upper>().solve(z);
    bl = -S.triangularView<Upper>().solve(z);
    //tl = -S.triangularView<Upper>().solve(S.triangularView<Upper>().transpose());


    br = (z.transpose() * z) - X_c;
    //cout << br << endl;
    //cout << br.rows() << endl;
    //cout << br.cols() << endl;

    Q << tl, tr, // .transpose();
         bl.transpose(), br;
    //cout << Q << endl;
    //cout << Q.rows() << endl;
    //cout << Q.cols() << endl;
}

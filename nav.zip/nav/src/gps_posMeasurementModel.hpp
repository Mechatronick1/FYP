#include <iostream>
#include "stateEstimator.h"
void gps_posMeasurementModel(const Eigen::VectorXd & x, const boatParameters params, Eigen::VectorXd & ENU, Eigen::MatrixXd & SR);
void rot(double R[3][3], const double angle, const int axis);
void rot3d(double R[3][3], const double reflat, const double reflon);
void matrixMultiply(double C[3][3], const double A[3][3], const double B[3][3]);
void matrixMultiply(double c[3], const double A[3][3], const double b[3]);

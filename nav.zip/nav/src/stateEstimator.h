#include <stdio.h>
#include "std_msgs/Float32.h"
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <Eigen/Core>
#include "rosgraph_msgs/Clock.h"
#include <time.h>
#include <sensor_msgs/NavSatFix.h>
#include "geometry_msgs/Vector3Stamped.h"
#include <sensor_msgs/Imu.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/Quaternion.h"
#include "geometry_msgs/Twist.h"
#include <tf/tf.h>
#include <Eigen/Geometry>
#include <fstream>
#include "gazebo_msgs/ModelStates.h"
//#include "rotation.h"

#ifndef STATEESTIMATOR_H
#define STATEESTIMATOR_H

class mainClass{
private:
        
        ros::NodeHandle nh;
        
        
        std::stringstream ss;
        int i;
public:
        ros::Subscriber subClock, subGPS_position, subGPS_velocity, subIMU;
        rosgraph_msgs::Clock simTime;
        
        sensor_msgs::NavSatFix positionVal[3];
        geometry_msgs::Vector3Stamped linearVelocity[3];
        sensor_msgs::Imu IMU[10];

mainClass() { // constructor starts the subscriber and publishers
        subClock  = nh.subscribe("/clock", 1, &mainClass::clockReadCallback, this);
        subGPS_position = nh.subscribe("/wamv/sensors/gps/gps/fix", 10, &mainClass::positionReadCallback, this);
        subGPS_velocity  = nh.subscribe("/wamv/sensors/gps/gps/fix_velocity", 10, &mainClass::velocityReadCallback, this);
        subIMU = nh.subscribe("/wamv/sensors/imu/imu/data", 10, &mainClass::imuReadCallback, this);
        }

        void clockReadCallback(const rosgraph_msgs::Clock::ConstPtr& msg) {
        // read simulation time and store it in variable
        simTime.clock = msg->clock;

        std::cout << simTime.clock << std::endl; 
        }


void positionReadCallback(const sensor_msgs::NavSatFix::ConstPtr& msg) {
        positionVal[ 0].latitude = msg->latitude;
        positionVal[ 1].longitude = msg->longitude;
        positionVal[ 2].altitude = msg->altitude;
}

void velocityReadCallback(const geometry_msgs::Vector3Stamped::ConstPtr& msg) {
      //Read GPS data and get velocity vectors
      linearVelocity[ 0].vector.x = msg->vector.x;
      linearVelocity[ 1].vector.y = msg->vector.y;
      linearVelocity[ 2].vector.z = msg->vector.z;
}

void imuReadCallback(const sensor_msgs::Imu::ConstPtr& msg) {
      //Read IMU data and get attitude (orientation) and attitude rate
      IMU[ 0].orientation.x = msg->orientation.x; //Magnetometer
      IMU[ 1].orientation.y = msg->orientation.y; //Magnetometer
      IMU[ 2].orientation.z = msg->orientation.z; //Magnetometer
      IMU[ 3].orientation.w = msg->orientation.w; //Magnetometer
      IMU[ 4].angular_velocity.x = msg->angular_velocity.x; //gyroscope
      IMU[ 5].angular_velocity.y = msg->angular_velocity.y; //gyroscope
      IMU[ 6].angular_velocity.z = msg->angular_velocity.z; //gyroscope
      IMU[ 7].linear_acceleration.x = msg->linear_acceleration.x; //Accel
      IMU[ 8].linear_acceleration.y = msg->linear_acceleration.y; //Accel
      IMU[ 9].linear_acceleration.z = msg->linear_acceleration.z; //Accel

    }

};


void stateEstimator();


struct BoatDynamics{
        void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx);
        void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, Eigen::MatrixXd & SQ);
        void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, Eigen::MatrixXd & SQ, Eigen::MatrixXd & Jx);
};

    struct boatParameters{
    
    double m = 250.9; //Mass
    double LCG = 1.3;
    double xG = 0.85;
    double yG = 0;
    double zG = -1.3;
    double TotalLength = 4.9;
    double Ixx = 225.12;
    double Ixy = -0.12;
    double Ixz = 0.83;
    double Iyy = 454.30;
    double Iyz = -0.2;
    double Izz = 499.86;
    //double B = 1.83;
    double g = 9.81;

    double density = 997.8;
    double Vdisp = 0.2277;
    double Awp_0 = 1.6;
    double GMT = 0.2;
    double GML = 0.19;

    double l_xL = -2.373780;   // Left motor x-dir dist from C.O.M [m]
    double l_yL = -1.027130;  // Left motor y-dir dist from C.O.M [m]
    double l_zL = 0.318237;   // Left motor z-dir dist from C.O.M [m]
    double l_xR = -2.373780;  // Right motor x-dir dist from C.O.M [m]
    double l_yR = 1.027130;   // Right motor y-dir dist from C.O.M [m]
    double l_zR = 0.318237;   // Left motor z-dir dist from C.O.M [m]
    double l_xF = 0.0;  // Right motor x-dir dist from C.O.M [m]
    double l_yF = 0.0;   // Right motor y-dir dist from C.O.M [m]
    double l_zF = 0.318237;   // Left motor z-dir dist from C.O.M [m]
    
    double X_udot = 0.0;
    double Y_vdot = 0.0;
    double N_rdot = 0.0;
    double Y_rdot = 0.0;
    double N_vdot = 0.0;
    double Z_wdot = 0.0;
    double K_pdot = 0.0;
    double M_qdot = 0.0;

    double X_u = 51.3;
    double X_uu = 72.4;
    double Y_v = 40.0;
    double Y_vv = 0.0;
    double Z_w = 500.0;
    double Z_ww = 0.0;
    double K_p = 50.0;
    double K_pp = 0.0;
    double M_q = 50.0;
    double M_qq = 0.0;
    double N_r = 400.0;
    double N_rr = 0.0;

        // get thrust values from topic
    double ThrCmdL = 0.0;
    double ThrCmdR = 0.0;
    double ThrCmdF = 0.0;
        //Thruster angles (setting to zero for now)
    double ThrAngL = 0.0;
    double ThrAngR = 0.0;
    double ThrAngF = 0.0;

     //Sensor indices
    double idx_acc = 1;
    double idx_gyro = 2;
    double idx_mag = 3;
    double idx_pos = 4;
    double idx_vel = 5;
    
    
        double origin_lat;
        double origin_long;
        double origin_alt;

        double latitude;
        double longitude;
        double altitude;

        double velx;
        double vely;
        double velz;
//-------------Converting quaternion to euler (roll pitch yaw)----------
        double roll;
        double pitch;
        double yaw;
//---------------------------------------------------------------------
        double gyrox;
        double gyroy;
        double gyroz;
        
        double accx;
        double accy;
        double accz;

   };
#endif

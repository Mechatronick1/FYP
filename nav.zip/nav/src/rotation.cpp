#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include "rotation.h"

Eigen::Matrix3d Rx(Eigen::VectorXd eta)
{
	Eigen::Matrix3d Rx;
	Rx <<	1, 0, 0,
			0, cos(eta[3]), -sin(eta[3]),
			0, sin(eta[3]), cos(eta[3]);
	return Rx;
}
Eigen::Matrix3d Ry(Eigen::VectorXd eta)
{
	Eigen::Matrix3d Ry;
	Ry <<   cos(eta[4]),	0, sin(eta[4]),
			0,				1, 0,
			-sin(eta[4]),	0, cos(eta[4]);
	return Ry;
}
Eigen::Matrix3d Rz(Eigen::VectorXd eta)
{
	Eigen::Matrix3d Rz;
	Rz <<	cos(eta[5]), -sin(eta[5]), 0,
			sin(eta[5]), cos(eta[5]), 0,
			0, 0, 1;
	return Rz;
}

Eigen::Matrix3d R(Eigen::VectorXd eta)
{
	Eigen::Matrix3d R;
	R = Rz(eta) * Ry(eta) * Rx(eta);
	return R;
}
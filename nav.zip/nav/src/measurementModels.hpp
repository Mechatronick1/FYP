#include <stdio.h>
#include "std_msgs/Float32.h"
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <Eigen/Core>
#include "rotation.h"

struct measurementModels{
        void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, boatParameters params, Eigen::VectorXd & ENU, Eigen::MatrixXd & SR);
        //void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, double latitude, double longitude, double altitude, double roll, double pitch, double yaw, double velx, double vely, double velz, double accx, double accy, double accz);
        //void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, double latitude, double longitude, double altitude, double roll, double pitch, double yaw, double velx, double vely, double velz, double accx, double accy, double accz);
        //void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, double E, double N, double U, double roll, double pitch, double yaw, double velx, double vely, double velz, double accx, double accy, double accz);
};
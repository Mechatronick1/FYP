#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include <eigen3/Eigen/Dense>
#include "gps_velMeasurementModel.hpp"
#include "stateEstimator.h"

#include <random>
//#include "stateEstimator.h"

void gps_velMeasurementModel(const Eigen::VectorXd & x, const boatParameters params,Eigen::VectorXd & vel_out, Eigen::MatrixXd & SR){
std::cout << "--------Start of GPS velocity--------" << std::endl;
double sigmar_u = 0.1; // velocity noise [m/s]

    // std::cout << "Velocity x dragged into function \n" << velx << std::endl;
    // std::cout << "Velocity y dragged into function \n" << vely << std::endl;
    // std::cout << "Velocity z dragged into function \n" << velz << std::endl;

        Eigen::MatrixXd eye2(2,2);
            eye2 <<
                1,0,
                0,1;


        Eigen::MatrixXd calc(3,3);
            calc <<
                0.01, 0, 0,
                0, 0.01, 0,
                0, 0, 0.01;
        //Finding the cholesky decomposition
        SR = calc.llt().matrixL();

        std::cout << "SR: " << SR << std::endl;

    // //Getting noise values between -1 and 1 (which is std of 1) - COULD BE BETTER, SEEMS TO REPEAT SAME NUMBERS
    // float random = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    // float random1 = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    // float random2 = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    // std::cout << "random value \n" << random << std::endl;
    // std::cout << "random value \n" << random1 << std::endl;
    // std::cout << "random value \n" << random2 << std::endl;
    // Eigen::VectorXd rand(3,1);
    // rand << random,
    //         random1,
    //         random2;


    Eigen::MatrixXd rMCb(3,1); //SHOULD NOT NEED TO DO THIS BECAUSE VELOCITY IS THE SAME NO MATTER POSITION OF POINT OF MASS
        rMCb <<
            0,
            0,
            0;

    // Check GyroMeasurementModel for comments about needing to double check to ensure this matrix is correct
    Eigen::MatrixXd Rbm(3,3);
        Rbm <<
            1,0,0,
            0,1,0,
            0,0,1;
        
        
    //eta
    Eigen::VectorXd eta(6,1);
    eta <<  x(0),    //x
            x(1),    //y
            x(2),    //z
            x(3),    //phi
            x(4),    //theta
            x(5);    //psi
    //nu
    Eigen::VectorXd nu(6,1);
    nu <<   x(6),    //u
            x(7),    //v
            x(8),    //w
            x(9),    //p
            x(10),   //q
            x(11);   //r
        


        //Need to do same thing here as gps pos 
    // Eigen::VectorXd y(3);
    // y << params.velx,
    //      params.vely,
    //      params.velz;
    
    vel_out.resize(3);
    vel_out(0) = params.velx;
    vel_out(1) = params.velx;
    vel_out(2) = params.velx;

    // Eigen::VectorXd y(3);
    // y << h + SR.transpose() * rand;
    // std::cout << "velocity with noise values: " << y << std::endl;

  //  return y;
//y is a vector of [velx,vely,velz]
}
#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include <chrono>
#include <thread>
#include <Eigen/Core>
#include <eigen3/Eigen/Dense>
#include "stateEstimator.h"
#include "measurementModels.hpp"


void measurementModels::operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, boatParameters params, Eigen::VectorXd & ENU, Eigen::MatrixXd & SR)
{
double a = 6378137.0;
double b = 6356752.314245;
double f = (a - b) / a;
double e_sq = f * (2 - f);


std::cout << "--------Start of GPS position--------" << std::endl;
double sigmar_V = 2.0; //vertical (north) position noise [m]
double sigmar_H = 0.85; //horizontal (east) position noise [m]


    // std::cout << "Latitude dragged into function \n" << latitude << std::endl;
    // std::cout << "Longitude dragged into function \n" << longitude << std::endl;
    // std::cout << "Altitude dragged into function \n" << altitude << std::endl;

    // std::cout << "origin lat" << origin_lat << std::endl;
    // std::cout << "origin long" << origin_long << std::endl;
    // std::cout << "otigin alt" << origin_alt << std::endl;

    //DONE ---- change sigma horizontal and vertical - check matlab
    //add noise to lat,long altitude - simulate measurement model
    //change to body fixed
   
        Eigen::MatrixXd calc(3,3);
            calc <<
                0.7225, 0, 0,
                0, 0.7225, 0,
                0, 0, 4.0;
        //Finding the cholesky decomposition
        SR = calc.llt().matrixL();

        std::cout << "SR: " << SR << std::endl;

        
        ////////////////////////////////// NEED TO ADD VALUES TO STATES-----------------CHECK PHOTOS
        Eigen::MatrixXd rMCb(3,1);
            rMCb <<
                0, //+0.85*cos(yaw) ------ NORTH......switch this with east so we are in ENU
                0 + 0.85, //*sin(yaw) ---- EAST.......switch this with north so we are in ENU
                0 - 1.3;  // --------------UP



        // Check GyroMeasurementModel for comments about needing to double check to ensure this matrix is correct
        Eigen::MatrixXd Rbm(3,3);
            Rbm <<
                1,0,0,
                0,1,0,
                0,0,1;
        
        
        //eta
        Eigen::VectorXd eta(6,1);
        eta << x(0),
               x(1),
               x(2),
               x(3),
               x(4),
               x(5); 
        

    Eigen::VectorXd h(3,1);
    h << params.latitude,
            params.longitude,
            params.altitude;


        double lambda0 = h[0] * (M_PI / 180);
        double phi0 = h[1] * (M_PI / 180);
        double s0 = sin(lambda0);
        double N0 = a / sqrt(1 - e_sq * s0 * s0);

        double sin_lambda0 = sin(lambda0);
        double cos_lambda0 = cos(lambda0);
        double cos_phi0 = cos(phi0);
        double sin_phi0 = sin(phi0);

        double x_car = (h[2] + N0) * cos_lambda0 * cos_phi0;
        double y_car = (h[2] + N0) * cos_lambda0 * sin_phi0;
        double z_car = (h[2] + (1 - e_sq) * N0) * sin_lambda0;

//Correct XYZ values
    std::cout << std::setprecision(12) << "X" << x_car << std::endl;
    std::cout << "Y" << y_car << std::endl;
    std::cout << "Z" << z_car << std::endl;


        double lambda = params.origin_lat * (M_PI/180) ;
        double phi = params.origin_long * (M_PI/180);
        double s = sin(lambda);
        double N = a / sqrt(1 - e_sq * s * s);

        double sin_lambda = sin(lambda);
        double cos_lambda = cos(lambda);
        double cos_phi = cos(phi);
        double sin_phi = sin(phi);

        double x0 = (params.origin_alt + N) * cos_lambda * cos_phi;
        double y0 = (params.origin_alt + N) * cos_lambda * sin_phi;
        double z0 = (params.origin_alt + (1 - e_sq) * N) * sin_lambda;

        double xd = x_car - x0;
        double yd = y_car - y0;
        double zd = z_car - z0;

        // This is the matrix multiplication
        double xEast = (-sin_phi * xd) + (cos_phi * yd);
        double yNorth = ((-cos_phi * sin_lambda) * xd) - ((sin_lambda * sin_phi) * yd) + (cos_lambda * zd);
        double zUp = ((cos_lambda * cos_phi) * xd) + ((cos_lambda * sin_phi) * yd) + (sin_lambda * zd);


    std::cout << "E" << xEast << std::endl;
    std::cout << "N" << yNorth << std::endl;
    std::cout << "U" << zUp << std::endl;

    // Eigen::VectorXd ENU(3,1);
    ENU << xEast,
           yNorth,
           zUp;

}

// void measurementModels::operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, double latitude, double longitude, double altitude, double roll, double pitch, double yaw, double velx, double vely, double velz, double accx, double accy, double accz, Eigen::VectorXd & vel, Eigen::MatrixXd & SR)
// {
// std::cout << "--------Start of GPS velocity--------" << std::endl;
// double sigmar_u = 0.1; // velocity noise [m/s]

//     std::cout << "Velocity x dragged into function \n" << velx << std::endl;
//     std::cout << "Velocity y dragged into function \n" << vely << std::endl;
//     std::cout << "Velocity z dragged into function \n" << velz << std::endl;

//         Eigen::MatrixXd eye2(2,2);
//             eye2 <<
//                 1,0,
//                 0,1;

//         Eigen::MatrixXd calc(3,3);
//             calc <<
//                 0.01, 0, 0,
//                 0, 0.01, 0,
//                 0, 0, 0.01;
//         //Finding the cholesky decomposition
//         Eigen::MatrixXd SR = calc.llt().matrixL();

//         std::cout << "SR: " << SR << std::endl;

//     //Getting noise values between -1 and 1 (which is std of 1) - COULD BE BETTER, SEEMS TO REPEAT SAME NUMBERS
//     float random = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
//     float random1 = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
//     float random2 = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
//     std::cout << "random value \n" << random << std::endl;
//     std::cout << "random value \n" << random1 << std::endl;
//     std::cout << "random value \n" << random2 << std::endl;
//     Eigen::VectorXd rand(3,1);
//     rand << random,
//             random1,
//             random2;


//     Eigen::MatrixXd rMCb(3,1); //SHOULD NOT NEED TO DO THIS BECAUSE VELOCITY IS THE SAME NO MATTER POSITION OF POINT OF MASS
//         rMCb <<
//             0,
//             0,
//             0;

//     // Check GyroMeasurementModel for comments about needing to double check to ensure this matrix is correct
//     Eigen::MatrixXd Rbm(3,3);
//         Rbm <<
//             1,0,0,
//             0,1,0,
//             0,0,1;
        
        
//     //eta
//     Eigen::VectorXd eta(6,1);
//     eta <<  x(0),    //x
//             x(1),    //y
//             x(2),    //z
//             x(3),    //phi
//             x(4),    //theta
//             x(5);    //psi
//     //nu
//     Eigen::VectorXd nu(6,1);
//     nu <<   x(6),    //u
//             x(7),    //v
//             x(8),    //w
//             x(9),    //p
//             x(10),   //q
//             x(11);   //r
        
//     Eigen::VectorXd vel(3,1);
//     vel << velx,
//          vely,
//          velz;
//     std::cout << "vel: " << vel << std::endl;


//     // Eigen::VectorXd y(3);
//     // y << h + SR.transpose() * rand;
//     // std::cout << "velocity with noise values: " << y << std::endl;


// //y is a vector of [velx,vely,velz]

// }

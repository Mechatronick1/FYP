#include <iostream>
void GyroMeasurementModel(const Eigen::VectorXd & x, const boatParameters params,Eigen::VectorXd & gyro_out, Eigen::MatrixXd & SR);

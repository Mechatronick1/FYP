#include <iostream>
#include "rotation.h"
void AccMeasurementModel(const Eigen::VectorXd & x, const boatParameters params,Eigen::VectorXd & acc_out, Eigen::MatrixXd & SR);

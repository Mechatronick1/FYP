#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include "stateEstimator.h"



int main(int argc, char **argv) {
//Needed this ros::init to remove the ros undefined error
ros::init(argc, argv, "navigation");

stateEstimator();
	
	return 0;
}
#include <stdio.h>
#include "std_msgs/Float32.h"
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <eigen3/Eigen/Dense>
//#include "rotation.h"

#ifndef STATEESTIMATOR_H
#define STATEESTIMATOR_H

void stateEstimator();



struct BoatDynamics{
        void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx);
        void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, Eigen::MatrixXd & SQ);
        void operator()(const Eigen::VectorXd & x, Eigen::VectorXd & dx, Eigen::MatrixXd & SQ, Eigen::MatrixXd & Jx);
};
#endif

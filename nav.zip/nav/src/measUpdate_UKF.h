// eulerKDE
#include <Eigen/Dense>

Eigen::MatrixXd mu0 = Eigen::MatrixXd::Zero(13, 1);
            mu0 <<
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0;

	double n = 13; //This changes between 13 and 26 in matlab, assuming 13 for now though
	double nsigma = 2*n+1;
	double alpha = 1;
	double kappa = 0;
	double lambda = alpha*alpha*(n+kappa) -n;
    double gamma = sqrt(n+lambda);
    
 std::cout << "lambda: " << lambda << endl;


				
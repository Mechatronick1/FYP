#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include <eigen3/Eigen/Dense>
#include "simulateMeasurement_gyro.hpp"
#include "GyroMeasurementModel.hpp"
#include "measurementModels.hpp"
#include <random>
#include "stateEstimator.h"

Eigen::VectorXd simulateMeasurement_gyro(Eigen::VectorXd & x, Eigen::VectorXd & dx, boatParameters params){

    //measurementModels gps_vel;

    Eigen::VectorXd gyro(3);
    Eigen::MatrixXd SR(3,3);
    GyroMeasurementModel(x, params, gyro, SR);
   // (ENU,SR) = gps_posMeasurementModel(x, dx, origin_lat, origin_long, origin_alt,latitude,longitude,altitude, roll, pitch, yaw, velx, vely, velz, accx, accy, accz, ENU, SR);

    float random = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    float random1 = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    float random2 = -1 + static_cast <float> (rand()) / ( static_cast <float> (RAND_MAX/(1+1)));
    std::cout << "random value \n" << random << std::endl;
    std::cout << "random value \n" << random1 << std::endl;
    std::cout << "random value \n" << random2 << std::endl;
    Eigen::VectorXd rand(3,1);
    rand << random,
            random1,
            random2;

    Eigen::VectorXd y(3);
    y << gyro + SR.transpose() * rand;
    std::cout << "---------------------OUTPUT OF SIMULATE MEASUREMENT MODEL GYRO: " << y << std::endl;


return y;
//y is a vector of [E,N,U]
}
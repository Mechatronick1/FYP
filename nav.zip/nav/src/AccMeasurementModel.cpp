#include "ros/ros.h"
#include <stdio.h>
#include <iostream>
#include <eigen3/Eigen/Dense>
#include "stateEstimator.h"
#include "AccMeasurementModel.hpp"

void AccMeasurementModel(const Eigen::VectorXd & x, const boatParameters params, Eigen::VectorXd & acc_out, Eigen::MatrixXd & SR){

double sigmar = 0.275*9.81; //Apparently stdev of accelerometer (ms^-2)
//std::cout << "STARTING ACCELERATION MEASUREMENT MODEL" << std::endl;
        //This calculation should be performed but just hard coding matrix values since i was getting errors 
        /* Eigen::MatrixXd eye3(3,3);
            eye3 <<
                1,0,0,
                0,1,0,
                0,0,1;

        double calc = (sigmar*sigmar)*eye3;
        */
        // std::cout << "Acc-x dragged into function \n" << accx << std::endl;
        // std::cout << "Acc-y dragged into function \n" << accy << std::endl;
        // std::cout << "Acc-z dragged into function \n" << accz << std::endl;


        Eigen::MatrixXd calc(3,3);
            calc <<
                7.277855,0,0,
                0,7.277855,0,
                0,0,7.277855;
       //Finding the cholesky decomposition
        SR = calc.llt().matrixL();

        //std::cout << "SR: " << SR << std::endl;

        Eigen::MatrixXd rMCb(3,1);
            rMCb <<
                0,
                0,
                0;
        Eigen::MatrixXd Rbm(3,3);
            Rbm <<
                1,0,0,
                0,1,0,
                0,0,1;
        
        
        //eta
        Eigen::VectorXd eta(6,1);
        eta << x(0),
               x(1),
               x(2),
               x(3),
               x(4),
               x(5); 
        //std::cout << "Changing first 6 values of x into eta: " << eta << std::endl;
        
        //b_acc
        //NEED TO COMPLETE THIS B_ACC IN ACCELEROMETER MEASUREMENT MODEL LINE 24
        //DONT THINK THIS SHOULD TECHNICALLY BE A 3x1 MATRIX, SHOULD JUST BE A 1x1 I THINK
        // Eigen::MatrixXd b_acc(3,1);
        // b_acc << 0,
        //          0,        
        //          0; //-0.0887 from matlab, NEED TO COME BACK AND WORK OUT HOW THIS IS FOUND LATER IF I GET TIME

        double b_acc = 0.0196;

        Eigen::MatrixXd Rnb(3,3);
        Rnb = R(eta);

        //std::cout << "Rnb " << Rnb << std::endl;

        Eigen::VectorXd dx(12);

        BoatDynamics model;
        model(x,dx);

 

        Eigen::VectorXd xdot(12);
        xdot <<  dx(0),
                 dx(1),
                 dx(2),
                 dx(3),
                 dx(4),
                 dx(5),
                 dx(6),
                 dx(7),
                 dx(8),
                 dx(9),
                 dx(10),
                 dx(11);
        //std::cout << "xdot: " << xdot << std::endl;


        Eigen::VectorXd aMNb(3);
        aMNb << xdot(7),
                xdot(8),
                xdot(9);
       // std::cout << "aMNb: " << aMNb << std::endl;

        Eigen::MatrixXd eye3(3,3);
        eye3 <<
                1,0,0,
                0,1,0,
                0,0,1;

        //Maybe try defining gn up the very top later
        Eigen::MatrixXd gn_temp(3,1);
        gn_temp <<
                0,
                0,
                9.81;

///////NEED TO ADD NOISE, REPLACE THE Y BELOW WITH H AND THEN CREATE THE Y FURTHER DOWN TO BE THE FINAL OUTPUT/RETURN
        //Eigen::VectorXd acc_out(3);

        // double first = (b_acc + aMNb(0) - 9.81*sin(eta(3))*sin(eta(5))-9.81*cos(eta(3))*cos(eta(5))*sin(eta(4)));
        // std::cout << "first: " << first << std::endl;

        // double second = (b_acc + aMNb(1) + 9.81*cos(eta(5))*sin(eta(3))-9.81*cos(eta(3))*sin(eta(5))*sin(eta(4)));

        // double third = (b_acc + aMNb(2) - 9.81*cos(eta(3))*cos(eta(4)));

        double first = (b_acc + aMNb(0) - 9.81*sin(eta(3))*sin(eta(5))-9.81*cos(eta(3))*cos(eta(5))*sin(eta(4)));
        //std::cout << "first: " << first << std::endl;

        double second = (b_acc + aMNb(1) + 9.81*cos(eta(5))*sin(eta(3))-9.81*cos(eta(3))*sin(eta(5))*sin(eta(4)));

        double third = (b_acc + aMNb(2) - 9.81*cos(eta(3))*cos(eta(4)));

        acc_out.resize(3);
        acc_out(0) = first;
        acc_out(1) = second;
        acc_out(2) = third;

//          std::cout << "---------------------acc_out0: " << acc_out(0) << std::endl;
//  std::cout << "---------------------acc_out1: " << acc_out(1) << std::endl;
//   std::cout << "---------------------acc_out2: " << acc_out(2) << std::endl;
//        acc_out << eye3*(aMNb-Rnb*gn_temp)+b_acc;
//        std::cout << "acc_out: " << acc_out << std::endl;

        // firstrow << eye3.row(0)*(aMNb.row(0)-Rnb.row(0)*gn_temp.row(0));


       //acc_out << eye3*(aMNb-Rnb*gn_temp)+b_acc;


        // acc_out.resize(3);
        // acc_out(0) = (aMNb-Rnb*gn_temp)+b_acc;
        // acc_out(1) = (aMNb-Rnb*gn_temp)+b_acc;
        // acc_out(2) = (aMNb-Rnb*gn_temp)+b_acc;

       std::cout << "acc_out: " << acc_out << std::endl;


// return y;
//return h;
}